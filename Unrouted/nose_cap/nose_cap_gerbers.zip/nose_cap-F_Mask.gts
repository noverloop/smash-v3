%TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*%
%TF.CreationDate,2026-10-26T13:31:20+01:00*%
%TF.ProjectId,nose_cap,6e6f7365-5f63-4617-902e-6b696361645f,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-10-26 13:31:20*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.000000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X-9899500Y9899500D03*
%TD*%
%TO.C,MH2*%
X9899500Y-9899500D03*
%TD*%
M02*
