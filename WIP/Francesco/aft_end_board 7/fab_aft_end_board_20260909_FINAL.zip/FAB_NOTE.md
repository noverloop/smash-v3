# aft_end_board — Fab package FINALE
Data: 2026-09-09

## Board
- 14 layer (F.Cu + In1..In12 + B.Cu), tondo ~Ø34, ENIG.
- 4 piani FLEX_GND su In1/In2/In11/In12 (riempiti, --check-zones).
- Test point bottom riorganizzati (a corona) + routati; **serigrafia bottom** con box + etichette di gruppo per i clienti.

## DRC
- 0 non-connessi. Errori = solo 14 courtyards_overlap (test point pogo vicini ai componenti) = advisory, accettati.
- Warning minori: silk_over_copper sui pad del connettore J su F.Cu (F.Silk preesistente), 4 dangling track/via (monconi innocui, net connessi), lib_footprint_mismatch (cosmetico).

## Drill
- 154 fori 0.20 mm (via passanti F↔B).

## Gerber (RS-274X)
F.Cu, In1..In12 (In1/In2/In11/In12 con pour FLEX_GND), B.Cu, F/B.Mask, F/B.Paste, F/B.Silkscreen (B.Silk = box+scritte gruppi), Edge.Cuts + drill + map + job.

Generato con kicad-cli 10.0.3 --check-zones.
