# aft_end_board — Fab package 2026-09-10

Sorgente: `G:\aft_end_board\aft_end_board.kicad_pcb` (KiCad 10, generator smash)

## Scheda
- Tondo Ø34 mm (Edge.Cuts = 2 archi R17), area 907.8 mm²
- **14 layer** rame: F.Cu, In1..In12, B.Cu — spessore stackup 2.225 mm
- 4 piani **FLEX_GND**: In1, In2, In11, In12 — riempiti in export (`--check-zones`)
- Min pista 0.100 mm, min clearance 0.0762 mm, min foro 0.200 mm
- Via: 156 passanti (0 cieche/sepolte/microvia) — DRU NCAB non-HDI
- Piazzole: 248 SMD, 0 through-hole, 0 NPTH
- 77 componenti (29 top, 48 bottom)

## Verifica (kicad-cli DRC, severity-all)
- **0 elementi non connessi**
- **0 short / 0 clearance / 0 track width / 0 hole clearance**
- 11 `courtyards_overlap` (advisory, accettati): test point a passo 2.0 mm con
  pad Ø1.5 → gap rame 0.23÷0.5 mm, nessuna violazione di clearance rame.
  TP coinvolti: ACT_MOTOR1..4, FIN_HALL, FIN_VREF, GPIO_0..3, NRST, SWO, BOOT0, BAT_RAW, BAT_PROT.
- 13 warning: 10 `lib_footprint_mismatch` (footprint 0402/TestPoint corretti a mano
  rispetto alla libreria — voluto), 3 serigrafia bottom (box I2C sopra i pad TP_I2C_SDA/SCL,
  cosmetico, clippato dalla solder mask).
- ERC: **non eseguibile** — il progetto non ha `.kicad_sch` (net name-based nel solo PCB).
  In sostituzione: netlist IPC-D-356 allegata per il test elettrico + parity check DRC = 0.

## Contenuto
| File | Contenuto |
|---|---|
| `*-F_Cu.gbr` … `*-B_Cu.gbr` | 14 layer rame (Gerber X2) |
| `*-F_Mask/B_Mask` | solder mask |
| `*-F_Paste/B_Paste` | stencil |
| `*-F_Silkscreen/B_Silkscreen` | serigrafia |
| `*-Edge_Cuts.gbr` | profilo Ø34 |
| `*-PTH.drl` | Excellon PTH — 156 fori T1 Ø0.200 mm |
| `*-NPTH.drl` | Excellon NPTH — **vuoto (0 fori)** |
| `*-PTH-drl_map.gbr` / `*-NPTH-drl_map.gbr` | mappe drill (Gerber X2) |
| `*-drill_report.txt` | report fori + stackup |
| `*-pos_all/top/bottom.csv` | pick&place mm, 77/29/48 componenti |
| `*-ipc356.d356` | netlist IPC-D-356 (test elettrico) |
| `*-stats.txt` | statistiche scheda |
| `*-job.gbrjob` | Gerber job file |

## Note per il fab
- Gerber X2, estensione KiCad (`.gbr`), precisione 6 cifre, origine assoluta.
- Il pick&place include **tutti** i 77 componenti (non è stato usato `--smd-only`:
  i footprint smash non hanno l'attributo SMD e verrebbero scartati).
