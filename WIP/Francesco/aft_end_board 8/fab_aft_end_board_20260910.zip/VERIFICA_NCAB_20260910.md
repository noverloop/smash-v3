# aft_end_board — Verifica contro le regole NCAB (2026-09-10)

Board: `G:\aft_end_board\aft_end_board.kicad_pcb` — 14 layer, Ø34 mm, stackup 2.225 mm.
Regole di riferimento: `G:\smash-electronics\hdi_fab_rules.md` (risposta NCAB, 2026-07).

## Premessa onesta
Il pacchetto fab `fab_aft_end_board_20260910` è stato generato usando il DRC **del progetto**
(`aft_end_board.kicad_dru` + netclass del `.kicad_pro`), che codifica **solo una parte** del set NCAB:
il `.kicad_dru` contiene le sole regole `hole_size ≥ 0.2mm` e `via_diameter ≥ 0.45mm`, e nel commento
dichiara di aver **rimosso** la regola via↔pista 150 µm considerandola HDI-specifica.
Le regole di clearance NCAB non erano quindi verificate. Questa è la verifica completa.

## Metodo
DRC KiCad 10 su copia della board con DRU che riproduce l'intero set NCAB
(ordine regole corretto: le specifiche dopo le generali, altrimenti KiCad le sovrascrive).

## Esito per regola

| Regola NCAB | Requisito | Esito | Minimo reale |
|---|---|---|---|
| Punta minima via meccanica | ≥ 200 µm | ✅ **OK** | 0.200 mm (tutte le 156 via) |
| Pad via meccanica | ≥ 450 µm | ✅ **OK** | 0.450 mm (tutte le 156 via) |
| Larghezza pista default | 100 µm | ✅ **OK** | 0.100 mm (tutti i 998 segmenti) |
| Foro ↔ foro | ≥ 250 µm | ✅ **OK** | 0 violazioni |
| Rame ↔ bordo scheda | ≥ 250 µm | ✅ **OK** | 0 violazioni |
| **Clearance rame-rame default** | **100 µm** | ⚠️ **91 punti sotto** | **0.075 mm** |
| **Via ↔ pista** | **150 µm** | ❌ **288 violazioni** | **0.0762 mm** |
| **Via ↔ via (bordo pad)** | **250 µm** | ❌ **10 violazioni** | **0.0776 mm** |
| **Aspect ratio foro** | non dichiarato da NCAB | ❌ **fuori standard** | **11.0 : 1** |

Totale: **389 violazioni** delle regole NCAB (più gli 11 `courtyards_overlap` già noti e accettati).
Restano confermati: 0 non connessi, 0 short, 0 elementi fuori bordo.

## 1. Clearance rame-rame: 75 µm invece di 100 µm — ⚠️ tollerabile
La netclass è impostata a **0.075 mm** board-wide. NCAB dà 100/100 µm come **default** e ammette
la riduzione a **70/70 µm "solo dove lo spazio lo impone"**.
75 µm è **sopra** il limite fisico dichiarato (70 µm), quindi è fabbricabile — ma è usato
su tutta la scheda, non come eccezione locale. Combinazione reale: **pista 100 µm / spazio 75 µm**.
→ Da dichiarare esplicitamente a NCAB in fase d'ordine.

## 2. Via ↔ pista sotto 150 µm: 288 violazioni — ❌ da sanare
Minimo 0.0762 mm, cioè metà del richiesto. Distribuzione:

| Layer | Violazioni |
|---|---|
| F.Cu | 340* |
| In9.Cu | 42 |
| In3.Cu | 41 |
| In5.Cu | 35 |
| In7.Cu | 34 |
| In4.Cu | 31 |
| In8.Cu | 20 |
| In10.Cu | 17 |
| In6.Cu | 11 |
| B.Cu | 5 |

\*conteggio per elemento coinvolto, non per violazione — il top è di gran lunga il layer peggiore.
Gap più frequente: **0.077 mm** (86 casi).

Questa regola era stata **rimossa consapevolmente** dal `.kicad_dru` con la motivazione
"è HDI-specifica". Nel documento NCAB però sta nella sezione generale
**"Clearance (rame-rame, misurate bordo-bordo)"**, non sotto microvia — la motivazione non regge.

## 3. Via ↔ via sotto 250 µm: 10 violazioni — ❌ le più critiche
Sono coppie di via passanti troppo vicine: margine di registrazione insufficiente.

| Gap reale | Net coinvolte | Posizione (mm) |
|---|---|---|
| **0.0776** | Y5_FIRE_SEL / EXT_CAN_P | (1.26, -2.75) |
| **0.0901** | FIRE_ARM_GD / ACTIVATE_CONFIRM | (-0.26, 1.80) |
| **0.0928** | SYS_SPI_SCLK / SYS_SPI_MOSI | (3.85, -11.31) |
| **0.1034** | BAT_RAW / SYS_SPI_SCLK | (3.41, -10.98) |
| 0.1215 | FIN3_AOUT1 / COMP_5V | (-0.50, -4.67) |
| 0.1538 | Y7_FIRE_SEL / NRST | (0.01, 5.34) |
| 0.1701 | Y12_FIRE_SEL / COMP_5V | (-0.13, -8.03) |
| 0.2047 | FLEX_GND / ACT_WIRE_0 | (2.55, 9.62) |
| 0.2141 | SYS_I2C_SDA / FIRE_ARM_G | (9.24, 5.43) |
| 0.2228 | FIRE_ARM_GD / ACTIVATE_SET | (-2.54, 7.54) |

Le prime 4 (< 0.11 mm) sono quelle da spostare per prime.
Nota: `BAT_RAW / SYS_SPI_SCLK / SYS_SPI_MOSI` formano un cluster attorno a (3.4÷4.3, -11).

## 4. Aspect ratio del foro: 11.0 : 1 — ❌ punto aperto col fab
- Spessore da forare = 2.225 − 0.02 (mask) = **2.205 mm**
- Punta = **0.200 mm** → **AR = 11.0 : 1**

Il documento NCAB non dà un numero: dice "foro finale **da adattare allo spessore da forare +
aspect ratio ammesso**", cioè lo lascia aperto. La galvanica standard di through-hole sta
tipicamente a 8:1, avanzata a 10:1. **11:1 è oltre lo standard** e va confermato da NCAB
prima di lanciare.

Se NCAB imponesse un limite:

| Limite AR | Punta minima | Pad (annular 0.125) |
|---|---|---|
| 8 : 1 | 0.276 → **Ø0.30** | Ø0.55 |
| 10 : 1 | 0.221 → **Ø0.25** | Ø0.50 |

**Attenzione all'effetto combinato**: allargare il pad da 0.45 a 0.50 mm toglie 0.05 mm
al gap via-via; il caso peggiore attuale (0.0776) scenderebbe a **0.0276 mm**. Cioè la
correzione dell'aspect ratio richiede *prima* di risolvere il punto 3.

## Conclusione
I file di fabbricazione generati sono **coerenti col DRC del progetto** (0 non connessi, 0 short),
ma **non sono conformi al set completo di regole NCAB**. Prima di mandarli in produzione servono
due decisioni:

1. **Chiedere a NCAB** l'aspect ratio ammesso per 2.205 mm di spessore e se accettano
   spazio 75 µm board-wide → determina se la board va rirouted.
2. Se le regole vanno rispettate: **rirouting mirato** dei 10 casi via-via e dei cluster
   via-pista su F.Cu (il layer peggiore), poi ri-generare il pacchetto fab.

Il DRU del progetto va comunque completato con le 3 regole mancanti
(clearance 100 µm, via↔pista 150 µm, via↔via 250 µm) perché la violazione oggi
**non è visibile nel DRC di KiCad**.
