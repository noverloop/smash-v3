# aft_end_board — punti da confermare prima di lanciare (per Nicolas)

Pacchetto: `fab_aft_end_board_20260910` — 14 layer, Ø34 mm, stackup 2.225 mm, 156 via passanti Ø0.20/pad Ø0.45, 77 componenti.

Stato: **DRC di progetto pulito** (0 non connessi, 0 short, 0 fuori bordo).
Ma la verifica contro il set NCAB completo (`VERIFICA_NCAB_20260910.md`) trova 389 deviazioni
che il DRC del progetto **non mostra**, perché il `.kicad_dru` non contiene quelle regole.

## 4 domande

1. **Aspect ratio.** 2.205 mm da forare / punta 0.200 = **11.0 : 1**.
   NCAB non ha dato un numero ("da adattare allo spessore + aspect ratio ammesso").
   → Lo accettano? Se il limite è 10:1 serve Ø0.25 (pad Ø0.50); se 8:1 serve Ø0.30 (pad Ø0.55).

2. **Via ↔ via.** Regola NCAB 250 µm bordo-bordo. Sulla board ci sono **10 coppie sotto**,
   la peggiore a **0.0776 mm** (Y5_FIRE_SEL / EXT_CAN_P @ 1.26,-2.75).
   → Si rirouta o si accetta il rischio di registrazione?

3. **Via ↔ pista.** Regola NCAB 150 µm. **288 violazioni**, gap tipico 0.077 mm, F.Cu il layer peggiore.
   La regola era stata tolta dal `.kicad_dru` come "HDI-specifica", ma nel documento NCAB
   sta sotto la sezione generale clearance rame-rame.
   → Vale o no per una board non-HDI come questa?

4. **Clearance rame-rame 75 µm board-wide.** NCAB: default 100/100, riduzione a 70/70
   "solo dove lo spazio lo impone". Qui è 100 µm di pista / 75 µm di spazio ovunque.
   Fabbricabile (75 > 70) ma non è una riduzione locale.
   → Si dichiara così in ordine o si riporta a 100 dove possibile?

## Incastro da tenere presente
I punti 1 e 2 sono legati: per scendere a 10:1 il pad passa da 0.45 a 0.50, cioè **−0.05 mm**
sul gap via-via. Il caso peggiore passerebbe da 0.0776 a **0.0276 mm**.
→ Se si tocca l'aspect ratio, il rirouting delle via-via diventa obbligatorio.

## Se va tutto bene
Il pacchetto è pronto com'è: Gerber X2 14 layer (piani FLEX_GND riempiti), Excellon PTH
156 fori Ø0.200 + NPTH vuoto, mappe drill, pick&place 77 componenti, netlist IPC-D-356.
Dettaglio in `FAB_NOTE.md`.
