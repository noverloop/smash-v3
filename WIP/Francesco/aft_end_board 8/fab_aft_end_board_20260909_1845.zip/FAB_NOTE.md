# aft_end_board — Fab package (rev 18:45, contact points organizzati + bottom re-routed)
Data: 2026-09-09
- 14 layer, tondo ~Ø34, ENIG. 4 piani FLEX_GND (In1/In2/In11/In12) riempiti (--check-zones).
- Test point organizzati in gruppi + bottom ri-routato + serigrafia bottom (box/etichette).
- DRC: 0 non-connessi, 0 short, 8 courtyards_overlap (advisory, accettati).
- Drill: 159 fori 0.20mm.
