# aft_end_board — Fab package
Data: 2026-09-09

## Board
- 14 layer (F.Cu + In1..In12 + B.Cu), tondo ~Ø34, ENIG.
- 4 piani FLEX_GND su In1 / In2 / In11 / In12 (riempiti nei gerber, --check-zones).
- Test point bottom (B.Cu) riorganizzati parzialmente per funzione + routati a mano.

## DRC
- 0 non-connessi, 0 short, 0 clearance. Restano 11 courtyards_overlap (test point pogo vicini ai componenti) = avvisi advisory, elettricamente innocui, accettati.

## Drill
- T1 = 0.20 mm : 154 fori (via passanti F↔B, size 0.45/0.2).

## Gerber (RS-274X)
F.Cu, In1..In12 (In1/In2/In11/In12 con pour FLEX_GND), B.Cu, F/B.Mask, F/B.Paste, F/B.Silkscreen, Edge.Cuts + drill (.drl) + map + job.

Generato con kicad-cli 10.0.3 --check-zones.
