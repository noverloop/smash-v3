%TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*%
%TF.CreationDate,2026-09-02T22:18:07+02:00*%
%TF.ProjectId,power_board,706f7765-725f-4626-9f61-72642e6b6963,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-09-02 22:18:07*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
