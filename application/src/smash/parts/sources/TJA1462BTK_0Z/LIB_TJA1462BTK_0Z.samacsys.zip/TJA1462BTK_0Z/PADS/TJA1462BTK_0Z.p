*PADS-LIBRARY-PART-TYPES-V9*

TJA1462BTK_0Z SON65P300X300X100-9N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.12.49.15
"Manufacturer_Name" NXP
"Manufacturer_Part_Number" TJA1462BTK/0Z
"Mouser Part Number" 771-TJA1462BTK/0Z
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/NXP-Semiconductors/TJA1462BTK-0Z?qs=DPoM0jnrROWYe7ZX1Wj2YQ%3D%3D
"Arrow Part Number" TJA1462BTK/0Z
"Arrow Price/Stock" https://www.arrow.com/en/products/tja1462btk0z/nxp-semiconductors?utm_currency=USD&region=nac
"Description" CAN Interface IC CAN SIC transceiver with Standby mode
"Datasheet Link" https://www.nxp.com/docs/en/data-sheet/TJA1462.pdf
"Geometry.Height" 1mm
GATE 1 9 0
TJA1462BTK_0Z
1 0 U TXD
2 0 U GND
3 0 U VCC
4 0 U RXD
9 0 U EP
8 0 U STB
7 0 U CANH
6 0 U CANL
5 0 U N.C.

*END*
*REMARK* SamacSys ECAD Model
14617835/2063303/2.50/9/3/Integrated Circuit
