*PADS-LIBRARY-PART-TYPES-V9*

DMP6110SVT-7 SOT95P280X100-6N I TRX 9 1 0 0 0
TIMESTAMP 2026.06.11.15.08.32
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" DMP6110SVT-7
"Mouser Part Number" 621-DMP6110SVT-7
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/DMP6110SVT-7?qs=AsTZqt%2FmeqnnPpRJnDG6UQ%3D%3D
"Arrow Part Number" DMP6110SVT-7
"Arrow Price/Stock" https://www.arrow.com/en/products/dmp6110svt-7/diodes-incorporated?region=nac
"Description" MOSFET 60V P-Ch Enh FET 60Vds 20Vgs
"Datasheet Link" https://www.diodes.com/assets/Datasheets/DMP6110SVT.pdf
"Geometry.Height" 1mm
GATE 1 6 0
DMP6110SVT-7
1 0 U D_1
2 0 U D_2
3 0 U G
6 0 U D_4
5 0 U D_3
4 0 U S

*END*
*REMARK* SamacSys ECAD Model
1298824/2063538/2.50/6/3/MOSFET (P-Channel)
