*PADS-LIBRARY-PART-TYPES-V9*

MT29F4G01ABAFD12-AAT_F BGA24C100P5X5_600X800X120 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.19.01.44
"Manufacturer_Name" Micron
"Manufacturer_Part_Number" MT29F4G01ABAFD12-AAT:F
"Mouser Part Number" 340-373012-TRAY
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Micron/MT29F4G01ABAFD12-AATF?qs=0lSvoLzn4L%252B5Hy445%2F7Pwg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Flash Memory, SLC NAND, 4 Gbit, 4G x 1bit, Serial, TBGA, 24 Pins , 2.7V ~ 3.6V , -40C ~ 105C (TC)
"Datasheet Link" https://4donline.ihs.com/images/VipMasterIC/IC/MICT/MICT-S-A0015861608/MICT-S-A0015861608-1.pdf?hkey=6D3A4C79FDBF58556ACFDE234799DDF0
"Geometry.Height" 1.2mm
GATE 1 24 0
MT29F4G01ABAFD12-AAT_F
A2 0 U NC_1
A3 0 U NC_2
A4 0 U NC_3
A5 0 U NC_4
B1 0 U NC_5
B2 0 U SCK
B3 0 U VSS
B4 0 U VCC
B5 0 U NC_6
C1 0 U DNU
C2 0 U CS#
C3 0 U NC_7
C4 0 U WP#/IO2
C5 0 U NC_8
D1 0 U NC_9
D2 0 U S0/IO1
D3 0 U S1/IO0
D4 0 U HOLD#/IO3
D5 0 U NC_10
E1 0 U NC_11
E2 0 U NC_12
E3 0 U NC_13
E4 0 U NC_14
E5 0 U NC_15

*END*
*REMARK* SamacSys ECAD Model
1699599/2063538/2.50/24/3/Integrated Circuit
