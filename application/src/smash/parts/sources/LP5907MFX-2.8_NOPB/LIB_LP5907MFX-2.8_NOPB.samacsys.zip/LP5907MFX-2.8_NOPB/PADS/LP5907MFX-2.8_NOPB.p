*PADS-LIBRARY-PART-TYPES-V9*

LP5907MFX-2.8_NOPB SOT95P280X145-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.25.16.36.53
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LP5907MFX-2.8/NOPB
"Mouser Part Number" 595-LP5907MFX-2.8NPB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LP5907MFX-2.8-NOPB?qs=biyDIajrTn5oMJBKg6r%2FuA%3D%3D
"Arrow Part Number" LP5907MFX-2.8/NOPB
"Arrow Price/Stock" https://www.arrow.com/en/products/lp5907mfx-2.8nopb/texas-instruments?utm_currency=USD&region=nac
"Description" 250-mA ultra-low-noise low-IQ low-dropout (LDO) linear regulator
"Datasheet Link" http://www.ti.com/lit/gpn/lp5907
"Geometry.Height" 1.45mm
GATE 1 5 0
LP5907MFX-2.8_NOPB
1 0 U IN
2 0 U GND
3 0 U EN
4 0 U N/C
5 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
567355/2063538/2.50/5/3/Integrated Circuit
