*PADS-LIBRARY-PART-TYPES-V9*

SN74LVC1G08DCKRG4 SOT65P210X110-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.25.17.58.18
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74LVC1G08DCKRG4
"Mouser Part Number" 595-SN74LVC1G08DCKG4
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74LVC1G08DCKRG4?qs=nqigI8dpoHKYOoxzksyiEQ%3D%3D
"Arrow Part Number" SN74LVC1G08DCKRG4
"Arrow Price/Stock" https://www.arrow.com/en/products/sn74lvc1g08dckrg4/texas-instruments?utm_currency=USD&region=nac
"Description" Single 2-Input Positive-AND Gate
"Datasheet Link" http://www.ti.com/lit/gpn/SN74LVC1G08
"Geometry.Height" 1.1mm
GATE 1 5 0
SN74LVC1G08DCKRG4
1 0 U A
2 0 U B
3 0 U GND
4 0 U Y
5 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
792349/2064551/2.50/5/3/Integrated Circuit
