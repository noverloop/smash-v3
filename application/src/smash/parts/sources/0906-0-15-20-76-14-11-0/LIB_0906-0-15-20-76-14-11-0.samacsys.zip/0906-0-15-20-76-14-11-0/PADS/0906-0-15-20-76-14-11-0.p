*PADS-LIBRARY-PART-TYPES-V9*

0906-0-15-20-76-14-11-0 0906015207614110 I CON 9 1 0 0 0
TIMESTAMP 2026.11.21.11.53.49
"Manufacturer_Name" Mill-Max
"Manufacturer_Part_Number" 0906-0-15-20-76-14-11-0
"Mouser Part Number" 575-906015
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Mill-Max/0906-0-15-20-76-14-11-0?qs=DGF5YW3GH8vs5H4c8CyXhQ%3D%3D
"Arrow Part Number" 0906-0-15-20-76-14-11-0
"Arrow Price/Stock" https://www.arrow.com/en/products/0906-0-15-20-76-14-11-0/mill-max?region=nac
"Description" MILL MAX - 0906-0-15-20-76-14-11-0 - Contact, Connector, THT, Spring Loaded Pin, Point, 2 A, 5.24 mm, 25 g
"Datasheet Link" https://www.mill-max.com/products/pin/0906/0906-0-15-20-76-14-11-0?s_term=0906-0-15-20-76-14-11-0&s_type=Quick%2FProduct%2FPart+Number+Search
"Geometry.Height" 3.4798mm
GATE 1 1 0
0906-0-15-20-76-14-11-0
1 0 U 1

*END*
*REMARK* SamacSys ECAD Model
2059852/2063303/2.50/1/3/Connector
