*PADS-LIBRARY-PART-TYPES-V9*

STLQ020C33R SOT65P210X110-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.25.17.17.04
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STLQ020C33R
"Mouser Part Number" 511-STLQ020C33R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STLQ020C33R?qs=%252B6g0mu59x7LMe2XkJbXkFw%3D%3D
"Arrow Part Number" STLQ020C33R
"Arrow Price/Stock" https://www.arrow.com/en/products/stlq020c33r/stmicroelectronics?utm_currency=USD&region=nac
"Description" LDO Voltage Regulators 200 mA ultra-low quiescent current LDO
"Datasheet Link" https://www.st.com/resource/en/datasheet/stlq020.pdf
"Geometry.Height" 1.1mm
GATE 1 5 0
STLQ020C33R
1 0 U VIN
2 0 U GND
3 0 U EN
4 0 U NC
5 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
2416190/2064551/2.50/5/2/Integrated Circuit
