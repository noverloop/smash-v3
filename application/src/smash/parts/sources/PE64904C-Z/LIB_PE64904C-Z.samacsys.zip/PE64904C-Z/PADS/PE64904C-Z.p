*PADS-LIBRARY-PART-TYPES-V9*

PE64904C-Z QFN50P200X200X50-10N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.17.14.22
"Manufacturer_Name" Peregrine Semiconductor
"Manufacturer_Part_Number" PE64904C-Z
"Mouser Part Number" 81-PE64904C-Z
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/pSemi/PE64904C-Z?qs=l7cgNqFNU1jACFJYawFELw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Trimmer / Variable Capacitors Digitally Tunable Capacitor (100-3000 MHz) SPI Interface
"Datasheet Link" https://www.psemi.com/pdf/datasheets/pe64904ds.pdf
"Geometry.Height" 0.5mm
GATE 1 10 0
PE64904C-Z
1 0 U RF-_1
2 0 U RF-_2
3 0 U DGND
4 0 U VDD
5 0 U SCL
9 0 U RF+_2
8 0 U RF+_1
7 0 U SDA
6 0 U SEN
10 0 U GND

*END*
*REMARK* SamacSys ECAD Model
1605218/2064551/2.50/10/3/Integrated Circuit
