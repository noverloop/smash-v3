*PADS-LIBRARY-PART-TYPES-V9*

S25HL512TFAMHI010 SOIC127P1030X265-16N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.17.27.12
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" S25HL512TFAMHI010
"Mouser Part Number" 727-S25HL512TFAMHI01
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/S25HL512TFAMHI010?qs=BJlw7L4Cy79W7OQMw6uPoQ%3D%3D
"Arrow Part Number" S25HL512TFAMHI010
"Arrow Price/Stock" https://www.arrow.com/en/products/s25hl512tfamhi010/cypress-semiconductor?region=nac
"Description" FLASH - NOR Memory IC 512Mbit SPI - Quad I/O 166 MHz 16-SOIC
"Datasheet Link" https://www.infineon.com/dgdl/Infineon-S25HS256T_S25HS512T_S25HS01GT_S25HL256T_S25HL512T_S25HL01GT_256Mb_512Mb_1Gb_Semper_Flash_with_Quad_SPI-DataSheet-v02_00-JA-DataSheet-v07_00-JA.pdf?fileId=8ac78c8c8afe5bd0018b4c22841d79e7
"Geometry.Height" 2.65mm
GATE 1 16 0
S25HL512TFAMHI010
1 0 U DQ3_/_RESET#
2 0 U VCC
3 0 U RESET#
4 0 U DNU_1
5 0 U DNU_2
6 0 U DNU_3
7 0 U CS#
8 0 U DQ1_/_SO
16 0 U CK
15 0 U DQ0_/_SI
14 0 U DNU_7
13 0 U DNU_6
12 0 U DNU_5
11 0 U DNU_4
10 0 U VSS
9 0 U DQ2_/_WP#

*END*
*REMARK* SamacSys ECAD Model
15107583/2063473/2.50/16/3/Integrated Circuit
