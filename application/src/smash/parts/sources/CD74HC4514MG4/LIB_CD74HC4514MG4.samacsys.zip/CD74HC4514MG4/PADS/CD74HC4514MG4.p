*PADS-LIBRARY-PART-TYPES-V9*

CD74HC4514MG4 SOIC127P1030X265-24N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.11.15.07.42
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" CD74HC4514MG4
"Mouser Part Number" 595-CD74HC4514MG4
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=595-CD74HC4514MG4
"Arrow Part Number" CD74HC4514MG4
"Arrow Price/Stock" https://www.arrow.com/en/products/cd74hc4514mg4/texas-instruments
"Description" Encoders, Decoders, Multiplexers & Demultiplexers Hi Spd CMOS Log 4-16 Line Decoder/Demult
"Datasheet Link" https://www.ti.com/lit/ds/symlink/cd74hc4514.pdf?HQS=dis-mous-null-mousermode-dsf-pf-null-wwe&ts=1619004310018&ref_url=https%253A%252F%252Fwww.mouser.in%252F
"Geometry.Height" 2.65mm
GATE 1 24 0
CD74HC4514MG4
1 0 U \LE
2 0 U A0
3 0 U A1
4 0 U Y7
5 0 U Y6
6 0 U Y5
7 0 U Y4
8 0 U Y3
9 0 U Y1
10 0 U Y2
11 0 U Y0
12 0 U GND
24 0 U VCC
23 0 U \E
22 0 U A3
21 0 U A2
20 0 U Y10
19 0 U Y11
18 0 U Y8
17 0 U Y9
16 0 U Y14
15 0 U Y15
14 0 U Y12
13 0 U Y13

*END*
*REMARK* SamacSys ECAD Model
630735/2063538/2.50/24/3/Integrated Circuit
