*PADS-LIBRARY-PART-TYPES-V9*

VEMD5110X01 VEMD5110X01 I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.12.51.17
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" VEMD5110X01
"Mouser Part Number" 78-VEMD5110X01
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Semiconductors/VEMD5110X01?qs=ZSTLft15nNCjtyEsdwkvPg%3D%3D
"Arrow Part Number" VEMD5110X01
"Arrow Price/Stock" https://www.arrow.com/en/products/vemd5110x01/vishay.html?utm_currency=USD&region=nac
"Description" PIN Photodiode 48uA 790-1050nm QFN
"Datasheet Link" https://www.vishay.com/docs/84204/vemd5110x01.pd
"Geometry.Height" 1.05mm
GATE 1 4 0
VEMD5110X01
1 0 U CATHODE_1
2 0 U CATHODE_2
3 0 U ANODE
4 0 U NC

*END*
*REMARK* SamacSys ECAD Model
1042578/2063303/2.50/4/3/Photodiode
