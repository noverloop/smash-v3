*PADS-LIBRARY-PART-TYPES-V9*

T545W477M006ATE035 T545W I CAP 9 1 0 0 0
TIMESTAMP 2026.11.21.21.19.56
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" T545W477M006ATE035
"Mouser Part Number" 80-T545W477M6ATE35
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/T545W477M006ATE035?qs=EYbNv5wfoHt2rATLjzirRQ%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" SMD, Polymer, Molded, Low Profile, HiEnergyDensity
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_T2079_SSD
"Geometry.Height" 1.5mm
GATE 1 2 0
T545W477M006ATE035
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
397265/2064551/2.50/2/2/Capacitor Polarised
