*PADS-LIBRARY-PART-TYPES-V9*

DRV5032FCDBZT SOT95P237X112-3N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.17.13.28.02
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DRV5032FCDBZT
"Mouser Part Number" 595-DRV5032FCDBZT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DRV5032FCDBZT?qs=u4fy%2FsgLU9Odn5O4YdzHXQ%3D%3D
"Arrow Part Number" DRV5032FCDBZT
"Arrow Price/Stock" https://www.arrow.com/en/products/drv5032fcdbzt/texas-instruments?region=nac
"Description" Ultra-Low Power 1.65V to 5.5V Hall Effect Switch
"Datasheet Link" http://www.ti.com/lit/gpn/DRV5032
"Geometry.Height" 1.12mm
GATE 1 3 0
DRV5032FCDBZT
1 0 U VCC
2 0 U OUT
3 0 U GND

*END*
*REMARK* SamacSys ECAD Model
872282/2063538/2.50/3/3/Integrated Circuit
