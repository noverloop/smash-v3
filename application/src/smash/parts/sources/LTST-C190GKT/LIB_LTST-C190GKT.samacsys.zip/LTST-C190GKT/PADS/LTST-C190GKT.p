*PADS-LIBRARY-PART-TYPES-V9*

LTST-C190GKT LEDC1608X90N I DIO 9 1 0 0 0
TIMESTAMP 2026.05.20.15.48.37
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C190GKT
"Mouser Part Number" 859-LTST-C190GKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/LITEON/LTST-C190GKT?qs=drxkyCeiWgbQzclgbojDOg%3D%3D
"Arrow Part Number" LTST-C190GKT
"Arrow Price/Stock" https://www.arrow.com/en/products/ltst-c190gkt/lite-on-technology?utm_currency=USD&region=nac
"Description" Standard LEDs - SMD Green Clear 569nm
"Datasheet Link" https://media.digikey.com/pdf/Data%20Sheets/Lite-On%20PDFs/LTST-C190GKT.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
LTST-C190GKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
12842258/2064551/2.50/2/0/LED
