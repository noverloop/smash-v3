*PADS-LIBRARY-PART-TYPES-V9*

SN74CB3T3125PWR SOP65P640X120-14N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.21.12.07.19
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74CB3T3125PWR
"Mouser Part Number" 595-SN74CB3T3125PWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74CB3T3125PWR/?qs=mE33ZKBHyE5AjFWEyhuB4Q%3D%3D
"Arrow Part Number" SN74CB3T3125PWR
"Arrow Price/Stock" https://www.arrow.com/en/products/sn74cb3t3125pwr/texas-instruments
"Description" 3.3-V Low-Voltage Quadruple FET Bus Switch with 5-V Tolerant Level Shifter
"Datasheet Link" http://www.ti.com/lit/gpn/sn74cb3t3125
"Geometry.Height" 1.2mm
GATE 1 14 0
SN74CB3T3125PWR
1 0 U 1\OE
2 0 U 1A
3 0 U 1B
4 0 U 2\OE
5 0 U 2A
6 0 U 2B
7 0 U GND
14 0 U VCC
13 0 U 4\OE
12 0 U 4A
11 0 U 4B
10 0 U 3\OE
9 0 U 3A
8 0 U 3B

*END*
*REMARK* SamacSys ECAD Model
690882/2063303/2.50/14/3/Integrated Circuit
