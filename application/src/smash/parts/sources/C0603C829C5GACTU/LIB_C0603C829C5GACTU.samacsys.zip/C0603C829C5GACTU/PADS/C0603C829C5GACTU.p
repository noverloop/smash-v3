*PADS-LIBRARY-PART-TYPES-V9*

C0603C829C5GACTU CAPC1608X87N I CAP 9 1 0 0 0
TIMESTAMP 2026.11.21.22.14.27
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" C0603C829C5GACTU
"Mouser Part Number" 80-C0603C829C5G
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=80-C0603C829C5G
"Arrow Part Number" C0603C829C5GACTU
"Arrow Price/Stock" https://www.arrow.com/en/products/c0603c829c5gactu/kemet-corporation
"Description" SMD, MLCC, Ultra-Stable, Low Loss, Class I
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_C1003_C0G_SMD
"Geometry.Height" 0.87mm
GATE 1 2 0
C0603C829C5GACTU
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
353110/2063473/2.50/2/2/Capacitor
