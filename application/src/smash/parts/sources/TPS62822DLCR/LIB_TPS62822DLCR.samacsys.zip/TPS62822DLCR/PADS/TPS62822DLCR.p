*PADS-LIBRARY-PART-TYPES-V9*

TPS62822DLCR SON50P150X200X100-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.22.56.50
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS62822DLCR
"Mouser Part Number" 595-TPS62822DLCR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS62822DLCR?qs=55YtniHzbhCS2IKlL8URbA%3D%3D
"Arrow Part Number" TPS62822DLCR
"Arrow Price/Stock" https://www.arrow.com/en/products/tps62822dlcr/texas-instruments
"Description" 2.4V-5.5V input, 2A step-down converter With 1% Accuracy in 1.5x2mm QFN
"Datasheet Link" http://www.ti.com/lit/gpn/tps62822
"Geometry.Height" 1mm
GATE 1 8 0
TPS62822DLCR
1 0 U EN
2 0 U FB
3 0 U AGND
4 0 U NC
8 0 U PG
7 0 U VIN
6 0 U SW
5 0 U PGND

*END*
*REMARK* SamacSys ECAD Model
1223159/2063473/2.50/8/3/Integrated Circuit
