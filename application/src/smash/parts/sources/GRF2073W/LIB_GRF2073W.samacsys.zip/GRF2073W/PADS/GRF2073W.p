*PADS-LIBRARY-PART-TYPES-V9*

GRF2073W SON50P200X200X80-9N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.18.09.52.47
"Manufacturer_Name" Guerrilla RF
"Manufacturer_Part_Number" GRF2073W
"Mouser Part Number" 459-GRF2073W
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Guerrilla-RF/GRF2073W?qs=hWgE7mdIu5R6JX88g0Mpyw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" RF Amplifier Ultra-Low Noise Amplifier: SDARS LNA, 2.0 - 6.0 GHz, AEC-Q100 Automotive Qualified
"Datasheet Link" https://www.guerrilla-rf.com/products/DataSheet?sku=2073-W&file_name=GRF2073WDS.pdf
"Geometry.Height" 0.8mm
GATE 1 9 0
GRF2073W
1 0 U VENABLE
2 0 U RF_IN
3 0 U GND/NC_1
4 0 U GND/NC_2
9 0 U GND
8 0 U GND/NC_5
7 0 U RF_OUT/VDD
6 0 U GND/NC_4
5 0 U GND/NC_3

*END*
*REMARK* SamacSys ECAD Model
13312513/2064551/2.50/9/3/Integrated Circuit
