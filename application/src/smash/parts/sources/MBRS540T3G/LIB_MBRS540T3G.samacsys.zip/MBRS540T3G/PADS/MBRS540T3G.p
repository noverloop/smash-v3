*PADS-LIBRARY-PART-TYPES-V9*

MBRS540T3G DIOM7958X256N I DIO 9 1 0 0 0
TIMESTAMP 2026.06.03.17.29.41
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" MBRS540T3G
"Mouser Part Number" 863-MBRS540T3G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi/MBRS540T3G?qs=3JMERSakebo5%2FaZU4XA2uw%3D%3D
"Arrow Part Number" MBRS540T3G
"Arrow Price/Stock" https://www.arrow.com/en/products/mbrs540t3g/on-semiconductor.html?utm_currency=USD&region=europe
"Description" Compact Surface Mountable Package with J-Bend leads; Rectangular Package for Automated Handling; Highly Stable Oxide Passivated Junction; Excellent Ability to Withstand Reverse Avalanche Energy Transients; Guardring for Stress Protection; Cathode Lead Indicated by polarity Notch; ESD Ratings, Machine Model = C, Human Body Model = 3B; Device Meets MSL 1 Requirements; Pb-Free Package is Available; AEC-Q101 Qualified and PPAP Capable; NRVB Prefix for Automotive and Other Applications Requiring Unique Site and 
"Datasheet Link" https://www.onsemi.com/pub/Collateral/MBRS540T3-D.PDF
"Geometry.Height" 2.56mm
GATE 1 2 0
MBRS540T3G
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
225033/2063538/2.50/2/2/Diode
