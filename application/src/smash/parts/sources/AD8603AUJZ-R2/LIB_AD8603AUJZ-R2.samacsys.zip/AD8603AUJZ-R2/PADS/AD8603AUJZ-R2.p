*PADS-LIBRARY-PART-TYPES-V9*

AD8603AUJZ-R2 SOT95P280X100-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.16.48.59
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" AD8603AUJZ-R2
"Mouser Part Number" 584-AD8603AUJZ-R2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/AD8603AUJZ-R2?qs=%2FtpEQrCGXCz806yK%2FNO2XQ%3D%3D
"Arrow Part Number" AD8603AUJZ-R2
"Arrow Price/Stock" https://www.arrow.com/en/products/ad8603aujz-r2/analog-devices?region=nac
"Description" AD8603AUJZ-R2, Operational Amplifier 0.4MHz CMOS, Rail-Rail, 3 V, 5-Pin TSOT
"Datasheet Link" http://componentsearchengine.com/Datasheets/3/AD8603AUJZ-R2.pdf
"Geometry.Height" 1mm
GATE 1 5 0
AD8603AUJZ-R2
1 0 U OUT
2 0 U V-
3 0 U +IN
4 0 U -IN
5 0 U V+

*END*
*REMARK* SamacSys ECAD Model
2349/2063303/2.50/5/3/Integrated Circuit
