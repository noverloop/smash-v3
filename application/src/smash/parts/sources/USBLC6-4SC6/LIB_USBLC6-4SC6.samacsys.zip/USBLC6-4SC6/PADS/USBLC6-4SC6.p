*PADS-LIBRARY-PART-TYPES-V9*

USBLC6-4SC6 SOT95P280X145-6N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.12.50.36
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" USBLC6-4SC6
"Mouser Part Number" 511-USBLC6-4SC6
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/USBLC6-4SC6?qs=k9dH%2Fx4GHJCNdehb8zInZg%3D%3D
"Arrow Part Number" USBLC6-4SC6
"Arrow Price/Stock" https://www.arrow.com/en/products/usblc6-4sc6/stmicroelectronics.html?utm_currency=USD&region=nac
"Description" 4 data-line protection  Protects VBUS  Very low capacitance: 3 pF typ.  Peak pulse power (8/20 s): 130 W typ.  SOT23-6L package  RoHS compliant
"Datasheet Link" https://www.st.com/resource/en/datasheet/usblc6-4.pdf
"Geometry.Height" 1.45mm
GATE 1 6 0
USBLC6-4SC6
1 0 U I/O1
2 0 U GND
3 0 U I/O2
6 0 U I/O4
5 0 U VBUS
4 0 U I/O3

*END*
*REMARK* SamacSys ECAD Model
3923/2063303/2.50/6/2/Integrated Circuit
