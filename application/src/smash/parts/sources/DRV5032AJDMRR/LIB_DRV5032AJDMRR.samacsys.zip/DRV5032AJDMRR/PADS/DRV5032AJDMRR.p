*PADS-LIBRARY-PART-TYPES-V9*

DRV5032AJDMRR DRV5032AJDMRR I ANA 9 1 0 0 0
TIMESTAMP 2026.11.21.09.37.02
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DRV5032AJDMRR
"Mouser Part Number" 595-DRV5032AJDMRR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DRV5032AJDMRR?qs=5aG0NVq1C4wOf7Do1hwL4g%3D%3D
"Arrow Part Number" DRV5032AJDMRR
"Arrow Price/Stock" https://www.arrow.com/en/products/drv5032ajdmrr/texas-instruments.html?utm_currency=USD&region=nac
"Description" Ultra-Low Power 1.65V to 5.5V Hall Effect Switch Sensor
"Datasheet Link" http://www.ti.com/lit/gpn/drv5032
"Geometry.Height" 0.4mm
GATE 1 5 0
DRV5032AJDMRR
1 0 U VCC
2 0 U GND
3 0 U NC
4 0 U OUT
5 0 U EP

*END*
*REMARK* SamacSys ECAD Model
963115/2063538/2.50/5/4/Integrated Circuit
