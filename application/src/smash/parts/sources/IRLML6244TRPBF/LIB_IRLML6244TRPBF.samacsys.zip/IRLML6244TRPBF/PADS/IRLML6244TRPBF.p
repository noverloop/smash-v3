*PADS-LIBRARY-PART-TYPES-V9*

IRLML6244TRPBF SOT95P237X112-3N I TRX 9 1 0 0 0
TIMESTAMP 2026.05.20.21.03.18
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" IRLML6244TRPBF
"Mouser Part Number" 942-IRLML6244TRPBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/IRLML6244TRPBF?qs=9%252BKlkBgLFf1HkY%2F2U%252BIhLQ%3D%3D
"Arrow Part Number" IRLML6244TRPBF
"Arrow Price/Stock" https://www.arrow.com/en/products/irlml6244trpbf/infineon-technologies-ag.html?utm_currency=USD&region=europe
"Description" INFINEON - IRLML6244TRPBF - MOSFET, N CH, 20V, 6.3A, SOT-23
"Datasheet Link" http://www.infineon.com/dgdl/irlml6244pbf.pdf?fileId=5546d462533600a4015356686fed261f
"Geometry.Height" 1.12mm
GATE 1 3 0
IRLML6244TRPBF
1 0 U G
2 0 U S
3 0 U D

*END*
*REMARK* SamacSys ECAD Model
367340/2063303/2.50/3/3/Transistor
