*PADS-LIBRARY-PART-TYPES-V9*

RR123-1H02-612 RR1231H02612 I ANA 9 1 0 0 0
TIMESTAMP 2026.07.30.09.52.24
"Manufacturer_Name" Coto Technology
"Manufacturer_Part_Number" RR123-1H02-612
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Digital Switch Special Purpose Push-Pull Magnetoresistive 4-LGA (1.45x1.45)
"Datasheet Link" https://www.digikey.ph/en/products/detail/coto-technology/rr123-1h02-612/25649459?msockid=39f1ec84d77b6f4428b7f904d6676eed
"Geometry.Height" 0.486mm
GATE 1 4 0
RR123-1H02-612
1 0 U LATCH_CONTROL
2 0 U VDD
3 0 U DIGITAL_OUT
4 0 U GND

*END*
*REMARK* SamacSys ECAD Model
20391081/2063473/2.50/4/3/Integrated Circuit
