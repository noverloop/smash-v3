*PADS-LIBRARY-PART-TYPES-V9*

TCAN1042GVDRBRQ1 SON65P300X300X100-9N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.20.20.00.30
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TCAN1042GVDRBRQ1
"Mouser Part Number" 595-TCAN1042GVDRBRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TCAN1042GVDRBRQ1?qs=HXFqYaX1Q2xW2rjX7Fpz5Q%3D%3D
"Arrow Part Number" TCAN1042GVDRBRQ1
"Arrow Price/Stock" https://www.arrow.com/en/products/tcan1042gvdrbrq1/texas-instruments.html?utm_currency=USD&region=nac
"Description" Automotive fault-protected CAN transceiver with I/O level shifting and 5-Mbps flexible data-rate
"Datasheet Link" https://www.ti.com/lit/gpn/TCAN1042GV-Q1
"Geometry.Height" 1mm
GATE 1 9 0
TCAN1042GVDRBRQ1
1 0 U TXD
2 0 U GND
3 0 U VCC
4 0 U RXD
9 0 U EP
8 0 U STB
7 0 U CANH
6 0 U CANL
5 0 U VIO

*END*
*REMARK* SamacSys ECAD Model
1594230/2064551/2.50/9/3/Integrated Circuit
