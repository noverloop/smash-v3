*PADS-LIBRARY-PART-TYPES-V9*

B3U-1000P B3U-1000P I SWI 8 1 0 0 0
TIMESTAMP 2026.11.21.13.54.57
"Manufacturer_Name" Aratas
"Manufacturer_Part_Number" B3U-1000P
"Mouser Part Number" 653-B3U-1000P
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Omron-Electronics/B3U-1000P?qs=AO7BQMcsEu4ip80xyf2FwA%3D%3D
"Arrow Part Number" B3U-1000P
"Arrow Price/Stock" https://www.arrow.com/en/products/b3u1000p/omron.html?utm_currency=USD&region=europe
"Description" OMRON ELECTRONIC COMPONENTS - B3U-1000P - SWITCH, SPST-NO, 0.05A, 12V, SMD
"Datasheet Link" https://www.omron.com/ecb/products/pdf/en-b3u.pdf
GATE 1 2 0
B3U-1000P
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
245073/2064551/2.50/2/4/Switch
