*PADS-LIBRARY-PART-TYPES-V9*

LMR10510YSDE_NOPB SON95P300X300X80-7N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.17.17.33
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMR10510YSDE/NOPB
"Mouser Part Number" 926-LMR10510YSDENOPB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMR10510YSDE-NOPB?qs=cN01o9PeIQsuiyAVd6pr4w%3D%3D
"Arrow Part Number" LMR10510YSDE/NOPB
"Arrow Price/Stock" https://www.arrow.com/en/products/lmr10510ysdenopb/texas-instruments?region=nac
"Description" Texas Instruments LMR10510YSDE/NOPB, Buck Converter, 1A, 5.5 V, Step Down, 3.75 MHz, 6-Pin, WSON
"Datasheet Link" http://www.ti.com/lit/gpn/lmr10510
"Geometry.Height" 0.8mm
GATE 1 7 0
LMR10510YSDE_NOPB
1 0 U FB
2 0 U GND
3 0 U SW
7 0 U DAP
6 0 U EN
5 0 U VINA
4 0 U VIND

*END*
*REMARK* SamacSys ECAD Model
414973/2065276/2.50/7/3/Integrated Circuit
