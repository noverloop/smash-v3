*PADS-LIBRARY-PART-TYPES-V9*

M24C01-RMN6TP SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.15.47.14
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" M24C01-RMN6TP
"Mouser Part Number" 511-M24C01-RMN6TP
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/M24C01-RMN6TP?qs=QKD%2FxyZmRHjtJPCg2QAvUQ%3D%3D
"Arrow Part Number" M24C01-RMN6TP
"Arrow Price/Stock" https://www.arrow.com/en/products/m24c01-rmn6tp/stmicroelectronics?utm_currency=USD&region=europe
"Description" 1-Kbit and 2-Kbit serial IC bus EEPROMs
"Datasheet Link" https://www.st.com/resource/en/datasheet/m24c01-w.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
M24C01-RMN6TP
1 0 U E0
2 0 U E1
3 0 U E2
4 0 U VSS
8 0 U VCC
7 0 U \WC
6 0 U SCL
5 0 U SDA

*END*
*REMARK* SamacSys ECAD Model
815564/2064551/2.50/8/2/Integrated Circuit
