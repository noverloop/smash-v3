*PADS-LIBRARY-PART-TYPES-V9*

LDL112PV18R SON95P300X300X100-7N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.21.03.54
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" LDL112PV18R
"Mouser Part Number" 511-LDL112PV18R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/LDL112PV18R?qs=Ok1pvOkw6%2FrJNgvWv3vE3g%3D%3D
"Arrow Part Number" LDL112PV18R
"Arrow Price/Stock" https://www.arrow.com/en/products/ldl112pv18r/stmicroelectronics?region=nac
"Description" 1.2 A low quiescent current LDO with reverse current protection
"Datasheet Link" https://www.st.com/resource/en/datasheet/ldl112.pdf
"Geometry.Height" 1mm
GATE 1 7 0
LDL112PV18R
1 0 U EN
2 0 U GND
3 0 U NC_1
7 0 U EP
6 0 U VIN
5 0 U NC_2
4 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
1149235/2063303/2.50/7/2/Integrated Circuit
