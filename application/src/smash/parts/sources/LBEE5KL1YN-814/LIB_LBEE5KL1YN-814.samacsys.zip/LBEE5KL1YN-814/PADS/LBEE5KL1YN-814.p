*PADS-LIBRARY-PART-TYPES-V9*

LBEE5KL1YN-814 LBEE5KL1YN814 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.15.47.58
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" LBEE5KL1YN-814
"Mouser Part Number" 81-LBEE5KL1YN-814
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/LBEE5KL1YN-814?qs=TCDPyi3sCW1FrH0sh%252Bb5wA%3D%3D
"Arrow Part Number" LBEE5KL1YN-814
"Arrow Price/Stock" https://www.arrow.com/en/products/lbee5kl1yn-814/murata-manufacturing?utm_currency=USD&region=nac
"Description" Bluetooth 802.11b/g/n, Bluetooth v5.2 Transceiver Module 2.4GHz ~ 2.4835GHz Antenna Not Included Surface Mount
"Datasheet Link" https://www.mouser.com/catalog/specsheets/Murata_LBEE5KL1YN-814.pdf
"Geometry.Height" 1.1mm
GATE 1 46 0
LBEE5KL1YN-814
1 0 U GND_1
2 0 U BT_UART_RXD
3 0 U BT_UART_TXD
4 0 U BT_UART_CTS_N
5 0 U BT_UART_RTS_N
6 0 U NC_1
7 0 U NC_2
8 0 U BT_PCM_SYNC
9 0 U BT_PCM_IN
10 0 U BT_PCM_OUT
11 0 U BT_PCM_CLK
12 0 U GND_2
13 0 U NC_3
14 0 U BT_REG_ON_
15 0 U NC_4
16 0 U NC_5
17 0 U WL_GPIO_2
18 0 U WL_GPIO_1
19 0 U GND_3
20 0 U SDIO_CLK
21 0 U GND_4
22 0 U SDIO_CMD
23 0 U SDIO_DATA_2
24 0 U SDIO_DATA_0
25 0 U SDIO_DATA_3
26 0 U SDIO_DATA_1
27 0 U WL_GPIO_0_HOST_WAKE
28 0 U WL_REG_ON
29 0 U GND_5
30 0 U VBAT
31 0 U VIN_LDO
32 0 U GND_(SR_PVSS)_1
33 0 U GND_(SR_PVSS)_2
34 0 U SR_VLX
35 0 U GND_6
36 0 U VIO
37 0 U LPO_IN_(32KHZ)
38 0 U BT_HOST_WAKE
39 0 U BT_DEV_WAKE
40 0 U GND_7
41 0 U ANT
42 0 U GND_8
43 0 U GND_9
44 0 U GND_10
45 0 U GND_11
46 0 U GND_12

*END*
*REMARK* SamacSys ECAD Model
16502821/2064551/2.50/46/2/Integrated Circuit
