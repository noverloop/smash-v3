*PADS-LIBRARY-PART-TYPES-V9*

STLQ020J30R BGA4C40P2X2_77X77X61 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.20.03.43
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STLQ020J30R
"Mouser Part Number" 511-STLQ020J30R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STLQ020J30R?qs=u4fy%2FsgLU9MJfI0qLS4mGA%3D%3D
"Arrow Part Number" STLQ020J30R
"Arrow Price/Stock" https://www.arrow.com/en/products/stlq020j30r/stmicroelectronics?utm_currency=USD&region=nac
"Description" LDO Voltage Regulators POWER MANAGEMENT
"Datasheet Link" https://www.st.com/resource/en/datasheet/stlq020.pdf
"Geometry.Height" 0.61mm
GATE 1 4 0
STLQ020J30R
A1 0 U VIN
A2 0 U VOUT
B1 0 U EN
B2 0 U GND

*END*
*REMARK* SamacSys ECAD Model
1710291/2063303/2.50/4/2/Integrated Circuit
