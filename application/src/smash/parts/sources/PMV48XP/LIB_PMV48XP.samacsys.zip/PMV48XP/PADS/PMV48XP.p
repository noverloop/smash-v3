*PADS-LIBRARY-PART-TYPES-V9*

PMV48XP SOT95P230X110-3N I ANA 8 1 0 0 0
TIMESTAMP 2026.11.21.22.14.40
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PMV48XP
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PMV48XP?qs=vHuUswq2%252BsyADRknxKe6jA%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" P-channel Trench MOSFET
"Datasheet Link" 
GATE 1 3 0
PMV48XP
1 0 U G
2 0 U S
3 0 U D

*END*
*REMARK* SamacSys ECAD Model
284994/2063473/2.50/3/0/Integrated Circuit
