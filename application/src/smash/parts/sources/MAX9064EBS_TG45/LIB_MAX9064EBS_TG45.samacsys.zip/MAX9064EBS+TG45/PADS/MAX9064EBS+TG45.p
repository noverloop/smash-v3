*PADS-LIBRARY-PART-TYPES-V9*

MAX9064EBS+TG45 BGA4C50P2X2_100X100X69 I ANA 9 1 0 0 0
TIMESTAMP 2026.11.23.09.10.20
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" MAX9064EBS+TG45
"Mouser Part Number" 700-MAX9064EBSTG45
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices-Maxim-Integrated/MAX9064EBS%2bTG45?qs=d3kjJb5aE2bi1a9imF7%2Fiw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" MAXIM INTEGRATED PRODUCTS - MAX9064EBS+TG45 - Analogue Comparator, Ultra Small, Low Power, 1 Comparator, 15 s, -0.3V to 5.5V, 1V to 5.5V, UCSP
"Datasheet Link" https://pdfserv.maximintegrated.com/en/ds/MAX9060-MAX9064.pdf
"Geometry.Height" 0.69mm
GATE 1 4 0
MAX9064EBS+TG45
A1 0 U OUT
A2 0 U IN
B1 0 U VCC
B2 0 U GND

*END*
*REMARK* SamacSys ECAD Model
609070/2063473/2.50/4/2/Integrated Circuit
