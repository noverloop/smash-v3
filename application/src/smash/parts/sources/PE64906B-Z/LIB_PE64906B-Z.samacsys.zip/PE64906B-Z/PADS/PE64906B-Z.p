*PADS-LIBRARY-PART-TYPES-V9*

PE64906B-Z QFN50P200X200X60-11N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.17.18.25.01
"Manufacturer_Name" Peregrine Semiconductor
"Manufacturer_Part_Number" PE64906B-Z
"Mouser Part Number" 81-PE64906B-Z
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/pSemi/PE64906B-Z?qs=l7cgNqFNU1iSxoklLRhTNg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" IC RF DTC 100-3000MHZ 10QFN
"Datasheet Link" http://www.psemi.com/pdf/datasheets/pe64906ds.pdf
"Geometry.Height" 0.6mm
GATE 1 11 0
PE64906B-Z
1 0 U RF-_1
2 0 U RF-_2
3 0 U GND_1
4 0 U VDD
5 0 U SCL
9 0 U RF+_2
8 0 U RF+_1
7 0 U SDA
6 0 U SEN
11 0 U EP
10 0 U GND_2

*END*
*REMARK* SamacSys ECAD Model
1209322/2063538/2.50/11/4/Integrated Circuit
