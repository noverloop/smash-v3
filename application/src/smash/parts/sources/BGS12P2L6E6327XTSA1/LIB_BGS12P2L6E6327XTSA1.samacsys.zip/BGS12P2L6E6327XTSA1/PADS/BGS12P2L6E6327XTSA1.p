*PADS-LIBRARY-PART-TYPES-V9*

BGS12P2L6E6327XTSA1 BGS12P2L6E6327XTSA1 I SWI 9 1 0 0 0
TIMESTAMP 2026.11.18.09.52.59
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" BGS12P2L6E6327XTSA1
"Mouser Part Number" 726-BGS12P2L6E6327XT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/BGS12P2L6E6327XTSA1?qs=mAH9sUMRCtuiUSQTWc4Zyg%3D%3D
"Arrow Part Number" BGS12P2L6E6327XTSA1
"Arrow Price/Stock" https://www.arrow.com/en/products/bgs12p2l6e6327xtsa1/infineon-technologies-ag.html?utm_currency=USD&region=nac
"Description" RF Switch IC GSM, LTE, W-CDMA SPDT 50Ohm PG-TSLP-6-4
"Datasheet Link" https://www.infineon.com/assets/row/public/documents/24/49/infineon-bgs12p2l6-datasheet-en.pdf?fileId=5546d4626cb27db2016d4487d53603ce
"Geometry.Height" 0.32mm
GATE 1 6 0
BGS12P2L6E6327XTSA1
1 0 U RF2
2 0 U GND
3 0 U RF1
4 0 U VDD
5 0 U RFIN
6 0 U CTRL

*END*
*REMARK* SamacSys ECAD Model
2335137/2064551/2.50/6/4/Switch
