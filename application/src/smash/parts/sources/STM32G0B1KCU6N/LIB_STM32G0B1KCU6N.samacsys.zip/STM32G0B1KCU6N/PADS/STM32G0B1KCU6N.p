*PADS-LIBRARY-PART-TYPES-V9*

STM32G0B1KCU6N QFN50P500X500X60-33N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.05.21.17.31.50
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32G0B1KCU6N
"Mouser Part Number" 511-STM32G0B1KCU6N
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32G0B1KCU6N?qs=QNEnbhJQKvZiP7%252BE0Q4OqQ%3D%3D
"Arrow Part Number" STM32G0B1KCU6N
"Arrow Price/Stock" https://www.arrow.com/en/products/stm32g0b1kcu6n/stmicroelectronics?utm_currency=USD&region=nac
"Description" Mainstream Arm Cortex-M0+ 32-bit MCU, up to 256KB Flash, 144KB RAM, 6x USART, timers, ADC, DAC, comm. I/Fs, 1.7-3.6V
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32g0b1cc.pdf
"Geometry.Height" 0.6mm
GATE 1 33 0
STM32G0B1KCU6N
1 0 U PB9
2 0 U PC14-OSC32_IN
3 0 U PC15-OSC32_OUT
4 0 U VDD/VDDA
5 0 U VSS/VSSA
6 0 U PF2-NRST
7 0 U PA0
8 0 U PA1
9 0 U PA2
10 0 U PA3
11 0 U PA4
12 0 U PA5
13 0 U PA6
14 0 U PA7
15 0 U PB0
16 0 U PB1
24 0 U PA13
23 0 U PA12_[PA10]
22 0 U PA11_[PA9]
21 0 U PA10
20 0 U VDDIO2
19 0 U PA9
18 0 U PA8
17 0 U PB15
33 0 U VSS
32 0 U PB8
31 0 U PB7
30 0 U PB6
29 0 U PD3
28 0 U PD2
27 0 U PD1
26 0 U PD0
25 0 U PA14-BOOT0

*END*
*REMARK* SamacSys ECAD Model
15822914/2065276/2.50/33/2/Integrated Circuit
