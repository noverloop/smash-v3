*PADS-LIBRARY-PART-TYPES-V9*

SSM3K35CTC_L3F SSM3J64CTCL3F I TRX 9 1 0 0 0
TIMESTAMP 2026.11.22.17.17.22
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" SSM3K35CTC,L3F
"Mouser Part Number" 757-SSM3K35CTCL3F
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/SSM3K35CTCL3F?qs=bKenfurwlsnCvFdll3YC1A%3D%3D
"Arrow Part Number" SSM3K35CTC,L3F
"Arrow Price/Stock" https://www.arrow.com/en/products/ssm3k35ctcl3f/toshiba?utm_currency=USD&region=nac
"Description" MOSFET Small-Signal MOSFET
"Datasheet Link" http://toshiba.semicon-storage.com/info/docget.jsp?did=29855&prodName=SSM3K35CTC
"Geometry.Height" 0.4mm
GATE 1 3 0
SSM3K35CTC_L3F
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
277531/2065276/2.50/3/4/MOSFET (N-Channel)
