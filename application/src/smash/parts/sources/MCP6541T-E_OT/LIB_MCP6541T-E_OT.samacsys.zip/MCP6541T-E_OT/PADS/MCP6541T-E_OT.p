*PADS-LIBRARY-PART-TYPES-V9*

MCP6541T-E_OT SOT95P270X145-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.10.58.23
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP6541T-E/OT
"Mouser Part Number" 579-MCP6541T-E/OT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP6541T-E-OT?qs=yUQqVecv4qupm9o8PkstNg%3D%3D
"Arrow Part Number" MCP6541T-E/OT
"Arrow Price/Stock" https://www.arrow.com/en/products/mcp6541t-eot/microchip-technology?utm_currency=USD&region=nac
"Description" Comparator Push-Pull RRIO 1.6V SOT23-5
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA6/571527.pdf
"Geometry.Height" 1.45mm
GATE 1 5 0
MCP6541T-E_OT
1 0 U OUT
2 0 U VSS
3 0 U VIN+
4 0 U VIN-
5 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
159452/2063538/2.50/5/3/Integrated Circuit
