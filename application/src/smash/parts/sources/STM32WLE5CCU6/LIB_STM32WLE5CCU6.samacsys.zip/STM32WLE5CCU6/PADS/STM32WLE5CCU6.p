*PADS-LIBRARY-PART-TYPES-V9*

STM32WLE5CCU6 QFN50P700X700X60-49N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.14.15.57.35
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32WLE5CCU6
"Mouser Part Number" 511-STM32WLE5CCU6
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32WLE5CCU6?qs=26oI9%252Bq63sLM90C6xjPI1g%3D%3D
"Arrow Part Number" STM32WLE5CCU6
"Arrow Price/Stock" https://www.arrow.com/en/products/stm32wle5ccu6/stmicroelectronics?utm_currency=USD&region=nac
"Description" Multiprotocol LPWAN 32-bit Arm Cortex-M4 MCUs, LoRa, (G)FSK, (G)MSK, BPSK, up to 256KB flash, 64KB SRAM
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32wle5c8.pdf
"Geometry.Height" 0.6mm
GATE 1 49 0
STM32WLE5CCU6
1 0 U PB3
2 0 U PB4
3 0 U PB5
4 0 U PB6
5 0 U PB7
6 0 U PB8
7 0 U PA0
8 0 U PA1
9 0 U PA2
10 0 U PA3
11 0 U VDD_1
12 0 U PA4
13 0 U PA5
14 0 U PA6
15 0 U PA7
16 0 U PA8
17 0 U PA9
18 0 U NRST
19 0 U PH3-BOOT0
20 0 U RFI_P
21 0 U RFI_N
22 0 U RFO_LP
23 0 U RFO_HP
24 0 U VR_PA
36 0 U PA13
35 0 U PA12
34 0 U PA11
33 0 U PA10
32 0 U PB12
31 0 U PB2
30 0 U PB0-VDD_TCXO
29 0 U VDDRF1V55
28 0 U VDDRF
27 0 U OSC_OUT
26 0 U OSC_IN
25 0 U VDDPA
49 0 U EP
48 0 U VSSSMPS
47 0 U VLXSMPS
46 0 U VDDSMPS
45 0 U VFBSMPS
44 0 U VDD_2
43 0 U PA15
42 0 U PA14
41 0 U VDDA
40 0 U PC15-OSC32_OUT
39 0 U PC14-OSC32_IN
38 0 U PC13
37 0 U VBAT

*END*
*REMARK* SamacSys ECAD Model
13167378/2063538/2.50/49/2/Integrated Circuit
