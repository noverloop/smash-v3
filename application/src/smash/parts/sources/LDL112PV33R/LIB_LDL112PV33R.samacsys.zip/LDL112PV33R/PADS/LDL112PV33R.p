*PADS-LIBRARY-PART-TYPES-V9*

LDL112PV33R SON95P300X300X100-7N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.20.02.08
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" LDL112PV33R
"Mouser Part Number" 511-LDL112PV33R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/LDL112PV33R?qs=ClYTdQWm4hBLK%252B6rgDdn2Q%3D%3D
"Arrow Part Number" LDL112PV33R
"Arrow Price/Stock" https://www.arrow.com/en/products/ldl112pv33r/stmicroelectronics?utm_currency=USD&region=nac
"Description" LDO Voltage Regulators 1.2 A low quiescent current LDO with reverse current protection
"Datasheet Link" https://www.st.com/resource/en/datasheet/ldl112.pdf
"Geometry.Height" 1mm
GATE 1 7 0
LDL112PV33R
1 0 U EN
2 0 U GND
3 0 U ADJ
7 0 U EP
6 0 U VIN
5 0 U NC
4 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
1099109/2063538/2.50/7/2/Integrated Circuit
