*PADS-LIBRARY-PART-TYPES-V9*

IRLML6402TRPBF SOT95P237X112-3N I TRX 9 1 0 0 0
TIMESTAMP 2026.05.20.20.01.57
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" IRLML6402TRPBF
"Mouser Part Number" 942-IRLML6402TRPBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/IRLML6402TRPBF?qs=9%252BKlkBgLFf0HuZuONx2Ewg%3D%3D
"Arrow Part Number" IRLML6402TRPBF
"Arrow Price/Stock" https://www.arrow.com/en/products/irlml6402trpbf/infineon-technologies-ag?utm_currency=USD&region=nac
"Description" MOSFET MOSFT P-Ch -3.7A 65mOhm 8nC Log Lvl
"Datasheet Link" http://www.infineon.com/dgdl/irlml6402pbf.pdf?fileId=5546d462533600a401535668d5c2263c
"Geometry.Height" 1.12mm
GATE 1 3 0
IRLML6402TRPBF
1 0 U G
2 0 U S
3 0 U D

*END*
*REMARK* SamacSys ECAD Model
551340/2063538/2.50/3/3/Transistor
