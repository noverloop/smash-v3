*PADS-LIBRARY-PART-TYPES-V9*

STPS1L60ZF SODFL3516X110N I DIO 9 1 0 0 0
TIMESTAMP 2026.11.20.18.26.28
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STPS1L60ZF
"Mouser Part Number" 511-STPS1L60ZF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STPS1L60ZF?qs=xjeEZJU9OeMcvgJ4Z2%252BLPg%3D%3D
"Arrow Part Number" STPS1L60ZF
"Arrow Price/Stock" https://www.arrow.com/en/products/stps1l60zf/stmicroelectronics
"Description" Schottky Diodes & Rectifiers DFD THYR TRIAC & RECTIFIER
"Datasheet Link" https://www.st.com/resource/en/datasheet/stps1l60.pdf
"Geometry.Height" 1.1mm
GATE 1 2 0
STPS1L60ZF
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
807604/2064551/2.50/2/2/Diode
