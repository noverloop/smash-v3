*PADS-LIBRARY-PART-TYPES-V9*

PMEG6010CEJ SODFL2512X80N I DIO 9 1 0 0 0
TIMESTAMP 2026.11.21.09.34.54
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PMEG6010CEJ
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PMEG6010CEJ?qs=vHuUswq2%252BszFNcEyOmBbtw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 1 A very low VF MEGA Schottky barrier rectifiers
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PMEG6010CEH_PMEG6010CEJ.pdf
"Geometry.Height" 0.8mm
GATE 1 2 0
PMEG6010CEJ
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
344312/2063538/2.50/2/4/Diode
