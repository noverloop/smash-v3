*PADS-LIBRARY-PART-TYPES-V9*

TPD4E05U06DQAR DQA(R-PUSON-N10) I DIO 8 1 0 0 0
TIMESTAMP 2026.11.21.11.53.21
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPD4E05U06DQAR
"Mouser Part Number" 595-TPD4E05U06DQAR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPD4E05U06DQAR?qs=%2FCrDlo5IrVPi4woOvWz0qA%3D%3D
"Arrow Part Number" TPD4E05U06DQAR
"Arrow Price/Stock" https://www.arrow.com/en/products/tpd4e05u06dqar/texas-instruments.html?utm_currency=USD&region=nac
"Description" 4-Channel Ultra-Low-Capacitance IEC ESD Protection Diode
"Datasheet Link" http://www.ti.com/lit/gpn/tpd4e05u06
GATE 1 10 0
TPD4E05U06DQAR
1 0 U D1+
2 0 U D1-
3 0 U GND_1
4 0 U D2+
5 0 U D2-
6 0 U NC_1
7 0 U NC_2
8 0 U GND_2
9 0 U NC_3
10 0 U NC_4

*END*
*REMARK* SamacSys ECAD Model
690408/2063303/2.50/10/4/Diode
