*PADS-LIBRARY-PART-TYPES-V9*

SSM3J372R_LF SSM3J372RLF I TRX 9 1 0 0 0
TIMESTAMP 2026.11.22.10.55.56
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" SSM3J372R,LF
"Mouser Part Number" 757-SSM3J372RLF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/SSM3J372RLF?qs=u16ybLDytRbJaSMlwq9MLA%3D%3D
"Arrow Part Number" SSM3J372R,LF
"Arrow Price/Stock" null?utm_currency=USD&region=nac
"Description" MOSFET P-CHANNEL VDSS:-30V VGSS:-12/+
"Datasheet Link" https://toshiba.semicon-storage.com/ap-en/semiconductor/product/mosfets/detail.SSM3J372R.html
"Geometry.Height" 0.88mm
GATE 1 3 0
SSM3J372R_LF
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
3576797/2063538/2.50/3/3/MOSFET (P-Channel)
