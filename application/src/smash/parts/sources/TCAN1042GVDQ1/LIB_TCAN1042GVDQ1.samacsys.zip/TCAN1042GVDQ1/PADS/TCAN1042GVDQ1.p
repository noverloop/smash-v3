*PADS-LIBRARY-PART-TYPES-V9*

TCAN1042GVDQ1 SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.16.33.43
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TCAN1042GVDQ1
"Mouser Part Number" 595-TCAN1042GVDQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TCAN1042GVDQ1?qs=yDQnu9hAfI8SnSPrz59qBA%3D%3D
"Arrow Part Number" TCAN1042GVDQ1
"Arrow Price/Stock" https://www.arrow.com/en/products/tcan1042gvdq1/texas-instruments
"Description" Automotive Fault Protected CAN Transceiver With Flexible Data-Rate
"Datasheet Link" http://www.ti.com/lit/gpn/tcan1042gv-q1
"Geometry.Height" 1.75mm
GATE 1 8 0
TCAN1042GVDQ1
1 0 U TXD
2 0 U GND
3 0 U VCC
4 0 U RXD
8 0 U STB
7 0 U CANH
6 0 U CANL
5 0 U VIO

*END*
*REMARK* SamacSys ECAD Model
750564/2063303/2.50/8/3/Integrated Circuit
