*PADS-LIBRARY-PART-TYPES-V9*

PESD2CANFD24V-QBZ PESD2CANFD24UQBZ I ANA 9 1 0 0 0
TIMESTAMP 2026.11.25.15.53.00
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PESD2CANFD24V-QBZ
"Mouser Part Number" 771-PESD2CANFD24VQBZ
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PESD2CANFD24V-QBZ?qs=KUoIvG%2F9IlaRXI2qgH77HQ%3D%3D
"Arrow Part Number" PESD2CANFD24V-QBZ
"Arrow Price/Stock" https://www.arrow.com/en/products/pesd2canfd24v-qbz/nexperia.html?utm_currency=USD&region=nac
"Description" PESD2CANFD24V-QB - ESD protection for In-vehicle networks
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PESD2CANFD24V-QB.pdf
"Geometry.Height" 0.5mm
GATE 1 4 0
PESD2CANFD24V-QBZ
1 0 U K1
2 0 U K2
3 0 U CC_1
4 0 U CC_2

*END*
*REMARK* SamacSys ECAD Model
13383042/2063303/2.50/4/2/Diode ESD (Uni-directional)
