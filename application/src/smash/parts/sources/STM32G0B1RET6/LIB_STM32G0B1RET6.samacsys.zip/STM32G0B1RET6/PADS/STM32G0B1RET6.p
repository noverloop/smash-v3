*PADS-LIBRARY-PART-TYPES-V9*

STM32G0B1RET6 QFP50P1200X1200X160-64N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.14.15.57.52
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32G0B1RET6
"Mouser Part Number" 511-STM32G0B1RET6
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32G0B1RET6?qs=pUKx8fyJudDnJgtz7LZZ0A%3D%3D
"Arrow Part Number" STM32G0B1RET6
"Arrow Price/Stock" https://www.arrow.com/en/products/stm32g0b1ret6/stmicroelectronics.html?utm_currency=USD&region=nac
"Description" Mainstream Arm Cortex-M0+ 32-bit MCU, up to 512KB Flash, 144KB RAM, 6x USART, timers, ADC, DAC, comm. I/Fs, 1.7-3.6V
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32g0b1cc.pdf
"Geometry.Height" 1.6mm
GATE 1 64 0
STM32G0B1RET6
1 0 U PC11
2 0 U PC12
3 0 U PC13
4 0 U PC14-OSC32_IN
5 0 U PC15-OSC32_OUT
6 0 U VBAT
7 0 U VREF+
8 0 U VDD/VDDA
9 0 U VSS/VSSA
10 0 U PF0-OSC_IN
11 0 U PF1-OSC_OUT
12 0 U PF2-NRST
13 0 U PC0
14 0 U PC1
15 0 U PC2
16 0 U PC3
17 0 U PA0
18 0 U PA1
19 0 U PA2
20 0 U PA3
21 0 U PA4
22 0 U PA5
23 0 U PA6
24 0 U PA7
25 0 U PC4
26 0 U PC5
27 0 U PB0
28 0 U PB1
29 0 U PB2
30 0 U PB10
31 0 U PB11
32 0 U PB12
48 0 U PC8
47 0 U PA15
46 0 U PA14-BOOT0
45 0 U PA13
44 0 U PA12_[PA10]
43 0 U PA11_[PA9]
42 0 U PA10
41 0 U PD9
40 0 U PD8
39 0 U PC7
38 0 U PC6
37 0 U PA9
36 0 U PA8
35 0 U PB15
34 0 U PB14
33 0 U PB13
64 0 U PC10
63 0 U PB9
62 0 U PB8
61 0 U PB7
60 0 U PB6
59 0 U PB5
58 0 U PB4
57 0 U PB3
56 0 U PD6
55 0 U PD5
54 0 U PD4
53 0 U PD3
52 0 U PD2
51 0 U PD1
50 0 U PD0
49 0 U PC9

*END*
*REMARK* SamacSys ECAD Model
13615780/2063538/2.50/64/2/Integrated Circuit
