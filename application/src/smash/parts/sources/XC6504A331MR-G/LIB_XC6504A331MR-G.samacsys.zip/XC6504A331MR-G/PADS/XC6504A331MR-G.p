*PADS-LIBRARY-PART-TYPES-V9*

XC6504A331MR-G SOT95P280X130-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.10.58.10
"Manufacturer_Name" Torex
"Manufacturer_Part_Number" XC6504A331MR-G
"Mouser Part Number" 865-XC6504A331MR-G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Torex-Semiconductor/XC6504A331MR-G?qs=AsjdqWjXhJ962wXvwTE8Xw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" LDO Voltage Regulators
"Datasheet Link" https://www.torexsemi.com/file/xc6504/XC6504.pdf
"Geometry.Height" 1.3mm
GATE 1 5 0
XC6504A331MR-G
1 0 U VIN
2 0 U VSS
3 0 U CE
4 0 U NC
5 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
1135571/2063538/2.50/5/2/Integrated Circuit
