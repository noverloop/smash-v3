*PADS-LIBRARY-PART-TYPES-V9*

LPS4018-103MRB INDPM3939X180N I IND 9 1 0 0 0
TIMESTAMP 2026.11.21.09.34.25
"Manufacturer_Name" COILCRAFT
"Manufacturer_Part_Number" LPS4018-103MRB
"Mouser Part Number" 994-LPS4018-103MRB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Coilcraft/LPS4018-103MRB?qs=QQJxVsr8EGYtnXPp5liaRw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" COILCRAFT - LPS4018-103MRB - INDUCTOR, 10UH, 20%, 0.9A, SHLD, SMD
"Datasheet Link" https://www.coilcraft.com/pdfs/lps4018.pdf
"Geometry.Height" 1.8mm
GATE 1 2 0
LPS4018-103MRB
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
258098/2063538/2.50/2/3/Inductor
