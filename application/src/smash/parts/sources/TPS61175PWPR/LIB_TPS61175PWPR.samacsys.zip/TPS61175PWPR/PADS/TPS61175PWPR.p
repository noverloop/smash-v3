*PADS-LIBRARY-PART-TYPES-V9*

TPS61175PWPR SOP65P640X120-15N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.18.24.54
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS61175PWPR
"Mouser Part Number" 595-TPS61175PWPR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS61175PWPR?qs=7IaIRco65pm0zx%252BYYPF1CQ%3D%3D
"Arrow Part Number" TPS61175PWPR
"Arrow Price/Stock" https://www.arrow.com/en/products/tps61175pwpr/texas-instruments?utm_currency=USD&region=nac
"Description" TEXAS INSTRUMENTS - TPS61175PWPR - DC-DC Switching Boost Step Up Regulator, Adjustable, 2.9V-18Vin, 2.2 MHz, 3Aout, HTSSOP-14
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tps61175.pdf?ts=1643090524950&ref_url=https%253A%252F%252Fwww.ti.com%252Fstore%252Fti%252Fen%252Fp%252Fproduct%252F%253Fp%253DTPS61175PWPR
"Geometry.Height" 1.2mm
GATE 1 15 0
TPS61175PWPR
1 0 U SW_1
2 0 U SW_2
3 0 U VIN
4 0 U EN
5 0 U SS
6 0 U SYNC
7 0 U AGND
15 0 U EP
14 0 U PGND_3
13 0 U PGND_2
12 0 U PGND_1
11 0 U NC
10 0 U FREQ
9 0 U FB
8 0 U COMP

*END*
*REMARK* SamacSys ECAD Model
4050733/2063538/2.50/15/3/Integrated Circuit
