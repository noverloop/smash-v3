*PADS-LIBRARY-PART-TYPES-V9*

LQG15HS1N8S02D LQG15WH0N7B02D I IND 9 1 0 0 0
TIMESTAMP 2026.11.23.08.41.28
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" LQG15HS1N8S02D
"Mouser Part Number" 81-LQG15HS1N8S02D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/LQG15HS1N8S02D?qs=ctz47l0uL1BEEZerGdIySA%3D%3D
"Arrow Part Number" LQG15HS1N8S02D
"Arrow Price/Stock" https://www.arrow.com/en/products/lqg15hs1n8s02d/murata-manufacturing
"Description" LQG15HS_02 Series Inductor 1.8nH +/-0.3nH 0402 (1005)
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/P02/JELF243B-0010.pdf
"Geometry.Height" 0.6mm
GATE 1 2 0
LQG15HS1N8S02D
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1348249/2063473/2.50/2/2/Inductor
