*PADS-LIBRARY-PART-TYPES-V9*

LTC5549IUDB#TRMPBF UDB_VARIATIONA I ANA 8 1 0 0 0
TIMESTAMP 2026.11.18.08.43.49
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" LTC5549IUDB#TRMPBF
"Mouser Part Number" 584-C5549IUDBTRMPBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/LTC5549IUDBTRMPBF?qs=oahfZPh6IAL1yoBcu%252BdUyQ%3D%3D
"Arrow Part Number" LTC5549IUDB#TRMPBF
"Arrow Price/Stock" https://www.arrow.com/en/products/ltc5549iudbtrmpbf/analog-devices?utm_currency=USD&region=nac
"Description" RF Mixer 2GHz to 14GHz Microwave Mixer with Integrated LO Frequency Doubler
"Datasheet Link" https://www.analog.com/media/en/technical-documentation/data-sheets/5549fa.pdf
GATE 1 13 0
LTC5549IUDB#TRMPBF
1 0 U GND_1
2 0 U IF
3 0 U GND_2
4 0 U GND_3
5 0 U RF
6 0 U GND_4
7 0 U EN
8 0 U X2
9 0 U VCC
10 0 U GND_5
11 0 U LO
12 0 U GND_6
13 0 U GND_7

*END*
*REMARK* SamacSys ECAD Model
1277876/2063538/2.50/13/4/Integrated Circuit
