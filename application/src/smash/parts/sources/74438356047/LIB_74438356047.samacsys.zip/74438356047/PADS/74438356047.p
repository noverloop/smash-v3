*PADS-LIBRARY-PART-TYPES-V9*

74438356047 74438356047 I IND 9 1 0 0 0
TIMESTAMP 2026.11.23.08.40.26
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 74438356047
"Mouser Part Number" 710-74438356047
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/74438356047?qs=E1W0Z3PUSachrucvBuNfiw%3D%3D
"Arrow Part Number" 74438356047
"Arrow Price/Stock" null?utm_currency=USD&region=asia
"Description" WE-MAPI SMT Power Inductor Size 4020; L = 4.7 H +/-20%; IR = 4 A; Isat = 5.75 A; RDC = 76 m
"Datasheet Link" https://www.we-online.com/catalog/datasheet/74438356047.pdf
"Geometry.Height" 2mm
GATE 1 2 0
74438356047
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
531975/2063473/2.50/2/2/Inductor
