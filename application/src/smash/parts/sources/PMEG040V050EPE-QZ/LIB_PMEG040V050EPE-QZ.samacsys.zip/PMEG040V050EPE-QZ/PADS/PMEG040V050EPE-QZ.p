*PADS-LIBRARY-PART-TYPES-V9*

PMEG040V050EPE-QZ PMEG040V050EPEQZ I DIO 9 1 0 0 0
TIMESTAMP 2026.09.02.21.08.02
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PMEG040V050EPE-QZ
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" PMEG040V050EPE-Q - 40 V, 5 A low VF Schottky barrier rectifier@en-us
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PMEG040V050EPE-Q.pdf
"Geometry.Height" 0.99mm
GATE 1 3 0
PMEG040V050EPE-QZ
1 0 U A_1
2 0 U A_2
3 0 U K

*END*
*REMARK* SamacSys ECAD Model
16679765/2063538/2.50/3/2/Schottky Diode
