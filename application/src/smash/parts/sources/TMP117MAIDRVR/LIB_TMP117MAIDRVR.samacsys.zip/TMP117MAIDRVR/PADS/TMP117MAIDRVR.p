*PADS-LIBRARY-PART-TYPES-V9*

TMP117MAIDRVR SON65P200X200X80-7N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.19.59.52
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TMP117MAIDRVR
"Mouser Part Number" 595-TMP117MAIDRVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TMP117MAIDRVR?qs=qSfuJ%252Bfl%2Fd6ns6kYPunSVg%3D%3D
"Arrow Part Number" TMP117MAIDRVR
"Arrow Price/Stock" https://www.arrow.com/en/products/tmp117maidrvr/texas-instruments.html?utm_currency=USD&region=nac
"Description" +/-0.1C Accurate Digital Temperature Sensor with Integrated NV Memory
"Datasheet Link" http://www.ti.com/lit/gpn/tmp117
"Geometry.Height" 0.8mm
GATE 1 7 0
TMP117MAIDRVR
1 0 U SCL
2 0 U GND
3 0 U ALERT
7 0 U EP
6 0 U SDA
5 0 U V+
4 0 U ADD0

*END*
*REMARK* SamacSys ECAD Model
1521666/2063538/2.50/7/3/Integrated Circuit
