*PADS-LIBRARY-PART-TYPES-V9*

SX1280 QFN50P400X400X100-25N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.13.09.41.46
"Manufacturer_Name" SEMTECH
"Manufacturer_Part_Number" SX1280
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" LoRa Connect Long Range Low Power LoRa 2.4GHz RF Transceiver With Ranging  Long Range 2.4 GHz transceiver  High sensitivity, down to -132 dBm  +12.5 dBm, high efficiency PA  Low energy consumption, on-chip DC-DC  LoRa, FLRC, (G)FSK supported modulations  Programmable bit rate  Excellent blocking immunity  Standard & Advanced Ranging Engine, Time-of-Flight  BLE PHY layer compatibility  Low system cost
"Datasheet Link" https://semtech.my.salesforce.com/sfc/p/E0000000JelG/a/2R000000HoCW/8EVYKPLcthcKCB_cKzApAc6Xf6tAHtn9.UKcOh7SNmg
"Geometry.Height" 1mm
GATE 1 25 0
SX1280
1 0 U VR_PA
2 0 U VDD_IN
3 0 U NRESET
4 0 U XTA
5 0 U GND_1
6 0 U XTB
7 0 U BUSY
8 0 U DIO1
9 0 U DIO2
10 0 U DIO3
11 0 U VBAT_IO
12 0 U DCC_FB
18 0 U SCK_RTSN
17 0 U MOSI_RX
16 0 U MISO_TX
15 0 U VBAT
14 0 U DCC_SW
13 0 U GND_2
25 0 U GND_7
24 0 U GND_6
23 0 U GND_5
22 0 U RFIO
21 0 U GND_4
20 0 U GND_3
19 0 U NSS_CTS

*END*
*REMARK* SamacSys ECAD Model
18467236/2063538/2.50/25/2/Integrated Circuit
