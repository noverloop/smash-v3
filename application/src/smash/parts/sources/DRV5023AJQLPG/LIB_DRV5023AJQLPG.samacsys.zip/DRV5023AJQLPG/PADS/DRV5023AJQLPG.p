*PADS-LIBRARY-PART-TYPES-V9*

DRV5023AJQLPG DRV5023AJQLPG I ANA 9 1 0 0 0
TIMESTAMP 2026.05.25.14.12.42
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DRV5023AJQLPG
"Mouser Part Number" 595-DRV5023AJQLPG
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DRV5023AJQLPG?qs=7z%252BmIopC6%2FLlfa8g4F1igg%3D%3D
"Arrow Part Number" DRV5023AJQLPG
"Arrow Price/Stock" https://www.arrow.com/en/products/drv5023ajqlpg/texas-instruments?utm_currency=USD&region=nac
"Description" Digital Switch Unipolar Switch Open Drain Hall Effect TO-92-3,2.5V ~ 38V,2.7mA (Typ),30mA -40C ~ 125C
"Datasheet Link" https://www.ti.com/lit/ds/symlink/drv5023.pdf
"Geometry.Height" 5.05mm
GATE 1 3 0
DRV5023AJQLPG
1 0 U VCC
2 0 U GND
3 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
15103874/2063538/2.50/3/3/Integrated Circuit
