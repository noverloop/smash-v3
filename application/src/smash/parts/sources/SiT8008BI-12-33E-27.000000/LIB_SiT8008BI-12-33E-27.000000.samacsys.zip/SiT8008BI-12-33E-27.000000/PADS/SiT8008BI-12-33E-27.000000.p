*PADS-LIBRARY-PART-TYPES-V9*

SiT8008BI-12-33E-27.000000 QFN_2520_4pins I OSC 9 1 0 0 0
TIMESTAMP 2026.11.21.22.15.48
"Manufacturer_Name" SiTime
"Manufacturer_Part_Number" SiT8008BI-12-33E-27.000000
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Low Power Programmable Oscillator
"Datasheet Link" https://www.sitime.com/support/resource-library/datasheets/sit8008-datasheet
"Geometry.Height" 0.8mm
GATE 1 4 0
SiT8008BI-12-33E-27.000000
1 0 U OE/\ST\/NC
2 0 U GND
3 0 U OUT
4 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
17703517/2063473/2.50/4/2/Crystal or Oscillator
