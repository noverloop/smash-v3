*PADS-LIBRARY-PART-TYPES-V9*

PE42442A-Z QFN50P400X400X80-25N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.16.10.29.34
"Manufacturer_Name" Peregrine Semiconductor
"Manufacturer_Part_Number" PE42442A-Z
"Mouser Part Number" 81-PE42442A-Z
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/pSemi/PE42442A-Z?qs=iw0hurA%2FaD3GGAlg9viEdg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" RF Switch ICs SP4T, High Iso, Absorptive, 50? RF Switch
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/PE42442A-Z.pdf
"Geometry.Height" 0.8mm
GATE 1 25 0
PE42442A-Z
1 0 U GND_1
2 0 U GND_2
3 0 U GND_3
4 0 U GND_4
5 0 U RF4
6 0 U GND_5
7 0 U GND_6
8 0 U RF3
9 0 U GND_7
10 0 U GND_8
11 0 U RF2
12 0 U GND_9
18 0 U V2
17 0 U V1
16 0 U VDD
15 0 U GND_11
14 0 U RF1
13 0 U GND_10
25 0 U EP
24 0 U GND_14
23 0 U GND_13
22 0 U RFC
21 0 U GND_12
20 0 U VSSEXT
19 0 U V3

*END*
*REMARK* SamacSys ECAD Model
1878589/2063538/2.50/25/3/Integrated Circuit
