*PADS-LIBRARY-PART-TYPES-V9*

TPS25940AQRVCTQ1 QFN50P300X400X80-21N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.23.58.25
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS25940AQRVCTQ1
"Mouser Part Number" 595-TPS25940AQRVCTQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS25940AQRVCTQ1?qs=osPbIpHqQ9WhMNzU6zUwHg%3D%3D
"Arrow Part Number" TPS25940AQRVCTQ1
"Arrow Price/Stock" https://www.arrow.com/en/products/tps25940aqrvctq1/texas-instruments
"Description" 2.7V-18V Automotive Current-Limited Load Switch with Current Sense & Short-to-Battery Protection
"Datasheet Link" http://www.ti.com/lit/gpn/TPS25940-Q1
"Geometry.Height" 0.8mm
GATE 1 21 0
TPS25940AQRVCTQ1
1 0 U DEVSLP
2 0 U PGOOD
3 0 U PGTH
4 0 U OUT_1
5 0 U OUT_2
6 0 U OUT_3
7 0 U OUT_4
8 0 U OUT_5
9 0 U IN_1
10 0 U IN_2
16 0 U GND
15 0 U OVP
14 0 U EN
13 0 U IN_5
12 0 U IN_4
11 0 U IN_3
21 0 U EP
20 0 U \FLT
19 0 U IMON
18 0 U DVDT
17 0 U ILIM

*END*
*REMARK* SamacSys ECAD Model
663086/2063303/2.50/21/3/Integrated Circuit
