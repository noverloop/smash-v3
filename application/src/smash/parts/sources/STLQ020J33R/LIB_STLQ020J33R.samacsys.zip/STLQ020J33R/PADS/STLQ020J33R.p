*PADS-LIBRARY-PART-TYPES-V9*

STLQ020J33R BGA4C40P2X2_77X77X61 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.25.15.33.12
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STLQ020J33R
"Mouser Part Number" 511-STLQ020J33R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STLQ020J33R?qs=u4fy%2FsgLU9Md%252B643lR9WRg%3D%3D
"Arrow Part Number" STLQ020J33R
"Arrow Price/Stock" https://www.arrow.com/en/products/stlq020j33r/stmicroelectronics?utm_currency=USD&region=europe
"Description" LDO Voltage Regulators 200 mA ultra-low quiescent current LDO
"Datasheet Link" https://www.st.com/resource/en/datasheet/stlq020.pdf
"Geometry.Height" 0.61mm
GATE 1 4 0
STLQ020J33R
A1 0 U VIN
A2 0 U VOUT
B1 0 U EN
B2 0 U GND

*END*
*REMARK* SamacSys ECAD Model
1376507/2063538/2.50/4/2/Integrated Circuit
