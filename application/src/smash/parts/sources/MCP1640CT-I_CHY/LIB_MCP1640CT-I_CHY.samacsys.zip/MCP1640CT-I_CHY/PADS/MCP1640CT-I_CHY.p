*PADS-LIBRARY-PART-TYPES-V9*

MCP1640CT-I_CHY SOT95P270X145-6N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.18.26.23
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP1640CT-I/CHY
"Mouser Part Number" 579-MCP1640CT-I/CHY
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP1640CT-I-CHY?qs=Z2DEGP6RHSmRdGno4hwnww%3D%3D
"Arrow Part Number" MCP1640CT-I/CHY
"Arrow Price/Stock" https://www.arrow.com/en/products/mcp1640ct-ichy/microchip-technology?region=nac
"Description" Synchronous Boost Regulator
"Datasheet Link" http://ww1.microchip.com/downloads/en/DeviceDoc/20002234D.pdf
"Geometry.Height" 1.45mm
GATE 1 6 0
MCP1640CT-I_CHY
1 0 U SW
2 0 U GND
3 0 U EN
6 0 U VIN
5 0 U VOUT
4 0 U VFB

*END*
*REMARK* SamacSys ECAD Model
238924/2063538/2.50/6/3/Integrated Circuit
