*PADS-LIBRARY-PART-TYPES-V9*

25SVPF330M 16SVF1000M I CAP 9 1 0 0 0
TIMESTAMP 2026.06.11.15.34.25
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" 25SVPF330M
"Mouser Part Number" 667-25SVPF330M
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/25SVPF330M?qs=OE1iw1LrrPHH21m7Sd4Nkw%3D%3D
"Arrow Part Number" 25SVPF330M
"Arrow Price/Stock" https://www.arrow.com/en/products/25svpf330m/panasonic?utm_currency=USD&region=europe
"Description" Capacitor SMD SVPFseries 25V 330uF Panasonic 330uF 25 V Polymer Aluminium Electrolytic Capacitor F12, OS-CON Series 5000h 10 x 12.6mm
"Datasheet Link" http://industrial.panasonic.com/cdbs/www-data/pdf/AAB8000/AAB8000C177.pdf
"Geometry.Height" 12.7mm
GATE 1 2 0
25SVPF330M
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
361929/2063538/2.50/2/2/Capacitor Polarised
