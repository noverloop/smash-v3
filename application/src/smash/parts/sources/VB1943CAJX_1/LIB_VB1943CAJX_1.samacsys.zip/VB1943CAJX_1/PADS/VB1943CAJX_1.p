*PADS-LIBRARY-PART-TYPES-V9*

VB1943CAJX_1 BGA74C80P9X10_890X1030X220 I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.10.55.43
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" VB1943CAJX/1
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" VB1943CAJX/1
"Arrow Price/Stock" https://www.arrow.com/en/products/vb1943cajx1/stmicroelectronics.html?utm_currency=USD&region=nac
"Description" Feature-rich 5 MP image sensors with dual global & rolling shutter
"Datasheet Link" https://www.st.com/en/imaging-and-photonics-solutions/vb1943.html
"Geometry.Height" 2.2mm
GATE 1 74 0
VB1943CAJX_1
A1 0 U AGND_1
A2 0 U CLK_RANGE0
A3 0 U CLK_RANGE1
A4 0 U CPNEG_OUT
A5 0 U CPNEG_IN
A6 0 U AGND_2
A7 0 U AGND_3
A8 0 U AGND_4
A9 0 U AGND_5
B1 0 U SCL
B2 0 U PORTEST
B3 0 U NC_1
B4 0 U NCG_1
B5 0 U AGND_6
B6 0 U AGND_7
B7 0 U AGND_8
B8 0 U AGND_9
B9 0 U CPPOS_OUT
C1 0 U SDA
C2 0 U NCG_2
C3 0 U NCG_3
C4 0 U VANA_1
C5 0 U VANA_2
C6 0 U VANA_3
C7 0 U VANA_4
C8 0 U VANA_5
C9 0 U CPPOS_IN
D1 0 U GPIO3
D2 0 U NC_2
D3 0 U NC_3
D7 0 U VANA_6
D8 0 U VANA_7
D9 0 U AGND_10
E1 0 U GPIO2
E2 0 U NC_4
E8 0 U DGND_1
E9 0 U VRT
F1 0 U GPIO1
F2 0 U NCG_4
F8 0 U VCORE_1
F9 0 U NC_5
G1 0 U GPIO0
G2 0 U VCORE_2
G3 0 U VCORE_3
G7 0 U VDDIO_1
G8 0 U VDDIO_2
G9 0 U NC_6
H1 0 U RESETN
H2 0 U DGND_2
H3 0 U DGND_3
H4 0 U LDO2V4
H5 0 U VANA_8
H6 0 U AGND_11
H7 0 U VCORE_4
H8 0 U VCORE_5
H9 0 U VCORE_6
J1 0 U DGND_4
J2 0 U DATA2N
J3 0 U DATA2P
J4 0 U DGND_5
J5 0 U DGND_6
J6 0 U DATA1N
J7 0 U DATA1P
J8 0 U DGND_7
J9 0 U EXTCLK
K1 0 U DGND_8
K2 0 U DATA3N
K3 0 U DATA3P
K4 0 U CLKN
K5 0 U CLKP
K6 0 U DATA4N
K7 0 U DATA4P
K8 0 U DGND_9
K9 0 U DGND_10

*END*
*REMARK* SamacSys ECAD Model
21198725/2063538/2.50/74/2/Integrated Circuit
