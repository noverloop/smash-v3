*PADS-LIBRARY-PART-TYPES-V9*

C0603C100J5GACTU CAPC1608X87N I CAP 9 1 0 0 0
TIMESTAMP 2026.11.21.22.14.16
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" C0603C100J5GACTU
"Mouser Part Number" 80-C0603C100J5G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/C0603C100J5GACTU?qs=c48R7eOJ3%252BgCjPer3VJnWg%3D%3D
"Arrow Part Number" C0603C100J5GACTU
"Arrow Price/Stock" https://www.arrow.com/en/products/c0603c100j5gactu/kemet-corporation?utm_currency=USD&region=nac
"Description" SMD Comm C0G, Ceramic, 10 pF, 5%, 50 VDC, 125 VDC, 125C, -55C, C0G, SMD, MLCC, Ultra-Stable, Low Loss, Class I, 0.1 % , 100 GOhms, 3.7 mg, 0603, 1.6mm, 0.8mm, 0.8mm, 0.7mm, 0.35mm, 4000, 78  Weeks, 120
"Datasheet Link" https://content.kemet.com/datasheets/KEM_C1003_C0G_SMD.pdf
"Geometry.Height" 0.87mm
GATE 1 2 0
C0603C100J5GACTU
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
183038/2063473/2.50/2/2/Capacitor
