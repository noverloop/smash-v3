*PADS-LIBRARY-PART-TYPES-V9*

BUK6D120-60PX BUK6D12060PX I TRX 9 1 0 0 0
TIMESTAMP 2026.11.21.09.36.12
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" BUK6D120-60PX
"Mouser Part Number" 771-BUK6D120-60PX
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/BUK6D120-60PX?qs=F5EMLAvA7IBtoNC2L3hOcQ%3D%3D
"Arrow Part Number" BUK6D120-60PX
"Arrow Price/Stock" https://www.arrow.com/en/products/buk6d120-60px/nexperia?utm_currency=USD&region=nac
"Description" MOSFET 60V P-CH TRENCHMOS SOT1220
"Datasheet Link" https://componentsearchengine.com/Datasheets/2/BUK6D120-60PX.pdf
"Geometry.Height" 0.65mm
GATE 1 8 0
BUK6D120-60PX
1 0 U D_1
2 0 U D_2
3 0 U G
4 0 U S_1
5 0 U D_3
6 0 U D_4
7 0 U D_5
8 0 U S_2

*END*
*REMARK* SamacSys ECAD Model
1425121/2063538/2.50/8/2/MOSFET (N-Channel)
