*PADS-LIBRARY-PART-TYPES-V9*

691137710002 SHDR2W70P0X500_1X2_1000X750X1150P I CON 9 1 0 0 0
TIMESTAMP 2026.11.22.18.27.32
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 691137710002
"Mouser Part Number" 710-691137710002
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/691137710002?qs=lBTPRtX1sU9LnHBbviNKGA%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" WR-TBL Terminal block - Wire protector - THT MRT12P5/2VE Serie 1377 - 5,0mm pitch - Monoblock THT - Green - Horizontal cable entry Wire Protector 11.5mm height - 02p
"Datasheet Link" https://www.we-online.com/catalog/datasheet/691137710002.pdf
"Geometry.Height" 11.5mm
GATE 1 2 0
691137710002
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
702134/2065276/2.50/2/2/Connector
