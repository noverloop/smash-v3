*PADS-LIBRARY-PART-TYPES-V9*

TMUX1111PWR SOP65P640X120-16N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.11.13.57.54
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TMUX1111PWR
"Mouser Part Number" 595-TMUX1111PWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TMUX1111PWR?qs=9r4v7xj2LnmViUWhkf3gLg%3D%3D
"Arrow Part Number" TMUX1111PWR
"Arrow Price/Stock" https://www.arrow.com/en/products/tmux1111pwr/texas-instruments?region=nac
"Description" 5-V low-leakage-current, 1:1 (SPST) 4-channel, precision switch (normally closed)
"Datasheet Link" http://www.ti.com/lit/gpn/TMUX1111
"Geometry.Height" 1.2mm
GATE 1 16 0
TMUX1111PWR
1 0 U SEL1
2 0 U D1
3 0 U S1
4 0 U N.C._1
5 0 U GND
6 0 U S4
7 0 U D4
8 0 U SEL4
16 0 U SEL2
15 0 U D2
14 0 U S2
13 0 U VDD
12 0 U N.C._2
11 0 U S3
10 0 U D3
9 0 U SEL3

*END*
*REMARK* SamacSys ECAD Model
2288197/2063538/2.50/16/3/Integrated Circuit
