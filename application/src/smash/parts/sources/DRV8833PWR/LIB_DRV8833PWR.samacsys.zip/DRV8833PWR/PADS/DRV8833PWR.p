*PADS-LIBRARY-PART-TYPES-V9*

DRV8833PWR SOP65P640X120-16N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.18.25.05
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DRV8833PWR
"Mouser Part Number" 595-DRV8833PWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DRV8833PWR?qs=biyDIajrTn6zZVfCUiXZ9g%3D%3D
"Arrow Part Number" DRV8833PWR
"Arrow Price/Stock" https://www.arrow.com/en/products/drv8833pwr/texas-instruments.html?utm_currency=USD&region=nac
"Description" 2A Low Voltage Dual Brushed DC or Single Bipolar Stepper Motor Driver (PWM Ctrl)
"Datasheet Link" http://www.ti.com/lit/gpn/drv8833
"Geometry.Height" 1.2mm
GATE 1 16 0
DRV8833PWR
1 0 U NSLEEP
2 0 U AOUT1
3 0 U AISEN
4 0 U AOUT2
5 0 U BOUT2
6 0 U BISEN
7 0 U BOUT1
8 0 U NFAULT
16 0 U AIN1
15 0 U AIN2
14 0 U VINT
13 0 U GND
12 0 U VM
11 0 U VCP
10 0 U BIN2
9 0 U BIN1

*END*
*REMARK* SamacSys ECAD Model
232779/2063538/2.50/16/3/Integrated Circuit
