*PADS-LIBRARY-PART-TYPES-V9*

SiT5356AECFQ-33N0-20.000000 Ceramic_QFN_5032_10pins I OSC 9 1 0 0 0
TIMESTAMP 2026.11.22.10.57.06
"Manufacturer_Name" SiTime
"Manufacturer_Part_Number" SiT5356AECFQ-33N0-20.000000
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Stratum 3 Elite Platform +/-100 ppb precision MEMS Super-TCXO
"Datasheet Link" https://www.sitime.com/support/resource-library/datasheets/sit5356-datasheet
"Geometry.Height" 1.06mm
GATE 1 10 0
SiT5356AECFQ-33N0-20.000000
1 0 U OE/VC/NC
2 0 U SCL/NC
3 0 U NC_1
4 0 U GND
5 0 U A0/NC
6 0 U CLK
7 0 U NC_2
8 0 U NC_3
9 0 U VDD
10 0 U SDA/NC

*END*
*REMARK* SamacSys ECAD Model
17672593/2063538/2.50/10/2/Crystal or Oscillator
