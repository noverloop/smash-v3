PCBNEW-LibModule-V1  2026-11-22 10:57:06
# encoding utf-8
Units mm
$INDEX
Ceramic_QFN_5032_10pins
$EndINDEX
$MODULE Ceramic_QFN_5032_10pins
Po 0 0 0 15 6b02ca82 00000000 ~~
Li Ceramic_QFN_5032_10pins
Cd Ceramic_QFN_5032_10pins
Kw Crystal or Oscillator
Sc 0
At SMD
AR 
Op 0 0 0
T0 0.000 -0 1.27 1.27 0 0.254 N V 21 N "Y**"
T1 0.000 -0 1.27 1.27 0 0.254 N I 21 N "Ceramic_QFN_5032_10pins"
DS -2.5 -1.6 2.5 -1.6 0.1 24
DS 2.5 -1.6 2.5 1.6 0.1 24
DS 2.5 1.6 -2.5 1.6 0.1 24
DS -2.5 1.6 -2.5 -1.6 0.1 24
DS -3.6 -2.7 3.6 -2.7 0.1 24
DS 3.6 -2.7 3.6 2.7 0.1 24
DS 3.6 2.7 -3.6 2.7 0.1 24
DS -3.6 2.7 -3.6 -2.7 0.1 24
DS -2.025 2.2 -2.025 2.2 0.1 21
DS -2.025 2.1 -2.025 2.1 0.1 21
DA -2.025 2.15 -2.025 2.2 -1800 0.1 21
DA -2.025 2.15 -2.025 2.1 -1800 0.1 21
$PAD
Po -2.025 1.175
Sh "1" R 1.050 1.150 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.600 1.025
Sh "2" R 0.700 1.350 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.600 1.025
Sh "3" R 0.700 1.350 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.025 1.175
Sh "4" R 1.050 1.150 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.025 -0
Sh "5" R 0.700 1.150 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.025 -1.175
Sh "6" R 1.050 1.150 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.600 -1.025
Sh "7" R 0.700 1.350 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.600 -1.025
Sh "8" R 0.700 1.350 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.025 -1.175
Sh "9" R 1.050 1.150 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.025 -0
Sh "10" R 0.700 1.150 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE Ceramic_QFN_5032_10pins
$EndLIBRARY
