*PADS-LIBRARY-PART-TYPES-V9*

DRV8428ERTER QFN50P300X300X80-17N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.21.09.35.36
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DRV8428ERTER
"Mouser Part Number" 595-DRV8428ERTER
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DRV8428ERTER?qs=IS%252B4QmGtzzpzdBY9S4N6Yw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Motor/Motion/Ignition Controllers & Drivers 35V, 1A bipolar stepper or dual brushed motor driver with integrated current sensing 16-WQFN -40 to 125
"Datasheet Link" https://www.ti.com/lit/gpn/drv8428e
"Geometry.Height" 0.8mm
GATE 1 17 0
DRV8428ERTER
1 0 U AOUT1
2 0 U AOUT2
3 0 U BOUT2
4 0 U BOUT1
5 0 U GND
6 0 U DVDD
7 0 U VREFB
8 0 U VREFA
12 0 U APH
11 0 U BEN
10 0 U BPH
9 0 U DECAY/TOFF
17 0 U EP
16 0 U PGND
15 0 U VM
14 0 U NSLEEP
13 0 U AEN

*END*
*REMARK* SamacSys ECAD Model
13633795/2063538/2.50/17/3/Integrated Circuit
