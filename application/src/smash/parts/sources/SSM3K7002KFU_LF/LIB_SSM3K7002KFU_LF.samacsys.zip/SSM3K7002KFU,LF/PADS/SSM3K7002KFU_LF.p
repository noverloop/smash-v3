*PADS-LIBRARY-PART-TYPES-V9*

SSM3K7002KFU_LF 1SS294LFT I TRX 9 1 0 0 0
TIMESTAMP 2026.11.22.17.17.10
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" SSM3K7002KFU,LF
"Mouser Part Number" 757-SSM3K7002KFULF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/SSM3K7002KFULF?qs=4XYteRzLj25k%2Fstii15gpQ%3D%3D
"Arrow Part Number" SSM3K7002KFU,LF
"Arrow Price/Stock" https://www.arrow.com/en/products/ssm3k7002kfulf/toshiba.html?utm_currency=USD&region=nac
"Description" MOSFET Small-signal MOSFET ID=0.4A VDSS=60V
"Datasheet Link" http://toshiba.semicon-storage.com/info/docget.jsp?did=35715&prodName=SSM3K7002KFU
"Geometry.Height" 1.4mm
GATE 1 3 0
SSM3K7002KFU_LF
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
910309/2065276/2.50/3/4/MOSFET (N-Channel)
