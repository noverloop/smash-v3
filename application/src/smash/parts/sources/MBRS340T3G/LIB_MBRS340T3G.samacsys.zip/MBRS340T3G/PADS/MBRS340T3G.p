*PADS-LIBRARY-PART-TYPES-V9*

MBRS340T3G DIOM8059X261N I DIO 9 1 0 0 0
TIMESTAMP 2026.05.20.15.48.26
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" MBRS340T3G
"Mouser Part Number" 863-MBRS340T3G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi/MBRS340T3G?qs=3JMERSakeboCr3wxBgfY3w%3D%3D
"Arrow Part Number" MBRS340T3G
"Arrow Price/Stock" https://www.arrow.com/en/products/mbrs340t3g/on-semiconductor?utm_currency=USD&region=europe
"Description" Case: Epoxy, Molded; Small Compact Surface Mountable Package with J-Bend Leads; Shipped in 16 mm Tape and Reel, 2500 units per reel; Excellent Ability to Withstand Reverse Avalanche Energy Transients; Rectangular Package for Automated Handling; Highly Stable Oxide Passivated Junction; Guardring for Stress Protection Mechanical Characteristics:; Weight: 217 mg (approximately); Marking: B32, B33, B34; Finish: All External Surfaces Corrosion Resistant and Terminal Leads are Readily Solderable; Polarity: Notch 
"Datasheet Link" https://www.onsemi.com/pub/Collateral/MBRS340T3-D.PDF
"Geometry.Height" 2.61mm
GATE 1 2 0
MBRS340T3G
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
171020/2064551/2.50/2/2/Diode
