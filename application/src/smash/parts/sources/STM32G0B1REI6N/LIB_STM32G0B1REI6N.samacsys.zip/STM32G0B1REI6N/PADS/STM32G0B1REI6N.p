*PADS-LIBRARY-PART-TYPES-V9*

STM32G0B1REI6N BGA64C50P8X8_500X500X60 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.21.16.38.38
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32G0B1REI6N
"Mouser Part Number" 511-STM32G0B1REI6N
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32G0B1REI6N?qs=CiayqK2gdcJ47BEp%2FM0WFg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Mainstream Arm Cortex-M0+ 32-bit MCU, up to 512KB Flash, 144KB RAM, 6x USART, timers, ADC, DAC, comm. I/Fs, 1.7-3.6V
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32g0b1cc.pdf
"Geometry.Height" 0.6mm
GATE 1 64 0
STM32G0B1REI6N
A1 0 U PC11
A2 0 U PC10
A3 0 U PB7
A4 0 U PB6
A5 0 U PD6
A6 0 U PD2
A7 0 U PD0
A8 0 U PC8
B1 0 U PC15-_OSC32__OUT
B2 0 U PC12
B3 0 U PB8
B4 0 U PB3
B5 0 U PD5
B6 0 U PD1
B7 0 U PC9
B8 0 U PA12_[PA10]
C1 0 U PC14-_OSC32__IN
C2 0 U PC13
C3 0 U PB9
C4 0 U PB4
C5 0 U PD4
C6 0 U PA15
C7 0 U PA14-_BOOT0
C8 0 U PA11_[PA9]
D1 0 U VDD/_VDDA
D2 0 U VREF+
D3 0 U VBAT
D4 0 U PB5
D5 0 U PD3
D6 0 U PA10
D7 0 U PA13
D8 0 U VDDIO_2
E1 0 U VSS/_VSSA
E2 0 U PF2-_NRST
E3 0 U PC0
E4 0 U PA7
E5 0 U PC7
E6 0 U PA9
E7 0 U PC6
E8 0 U VSS
F1 0 U PF0-_OSC_I_N
F2 0 U PC1
F3 0 U PA3
F4 0 U PA6
F5 0 U PB0
F6 0 U PB14
F7 0 U PB15
F8 0 U PA8
G1 0 U PF1-_OSC__OUT
G2 0 U PC2
G3 0 U PA2
G4 0 U PA5
G5 0 U PB1
G6 0 U PB10
G7 0 U PB12
G8 0 U PB13
H1 0 U PC3
H2 0 U PA0
H3 0 U PA1
H4 0 U PA4
H5 0 U PC4
H6 0 U PC5
H7 0 U PB2
H8 0 U PB11

*END*
*REMARK* SamacSys ECAD Model
13699524/2065276/2.50/64/2/Integrated Circuit
