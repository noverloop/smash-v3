*PADS-LIBRARY-PART-TYPES-V9*

NCS1-292+ NCS1292 I XFR 9 1 0 0 0
TIMESTAMP 2026.11.22.17.16.53
"Manufacturer_Name" Mini-Circuits
"Manufacturer_Part_Number" NCS1-292+
"Mouser Part Number" 139-NCS1-292
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Mini-Circuits/NCS1-292%2b?qs=xZ%2FP%252Ba9zWqbHq51xjfjA3w%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Signal Conditioning RF XFMR / SURF MT / RoHS ,,,
"Datasheet Link" 
"Geometry.Height" 1.069mm
GATE 1 6 0
NCS1-292+
1 0 U PRIMARY_DOT_(UNBALANCED_PORT)
2 0 U GND_OR_DC_FEED_+_RF_GND
3 0 U SECONDARY_(BALANCED)
4 0 U SECONDARY_DOT_(BALANCED)
5 0 U NOT_USED_(GND_EXTREMALLY)
6 0 U NO_CONNECTION

*END*
*REMARK* SamacSys ECAD Model
11558245/2065276/2.50/6/3/Transformer
