*PADS-LIBRARY-PART-TYPES-V9*

LMR10510XMFE_NOPB SOT95P280X145-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.21.04.05
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMR10510XMFE/NOPB
"Mouser Part Number" 926-LMR10510XMFENOPB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMR10510XMFE-NOPB?qs=cN01o9PeIQt6Gu2gtl1ODA%3D%3D
"Arrow Part Number" LMR10510XMFE/NOPB
"Arrow Price/Stock" https://www.arrow.com/en/products/lmr10510xmfenopb/texas-instruments?region=nac
"Description" Texas Instruments LMR10510XMFE/NOPB, Buck Converter, 1A, 5.5 V, Step Down, 1.95 MHz, 5-Pin, SOT-23
"Datasheet Link" http://www.ti.com/lit/gpn/lmr10510
"Geometry.Height" 1.45mm
GATE 1 5 0
LMR10510XMFE_NOPB
1 0 U SW
2 0 U GND
3 0 U FB
4 0 U EN
5 0 U VIN

*END*
*REMARK* SamacSys ECAD Model
414971/2063303/2.50/5/3/Integrated Circuit
