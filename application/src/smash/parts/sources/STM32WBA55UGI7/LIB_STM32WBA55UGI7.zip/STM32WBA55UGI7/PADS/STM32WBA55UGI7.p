*PADS-LIBRARY-PART-TYPES-V9*

STM32WBA55UGI7 BGA59C50P8X8_500X500X60 I ANA 9 1 0 0 0
TIMESTAMP 2026.11.15.19.31.01
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32WBA55UGI7
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Multiprotocol wireless 32-bit MCU Arm-based Cortex-M33 with TrustZone, FPU, Bluetooth LE and IEEE 802.15.4 radio solution
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32wba52ce.pdf
"Geometry.Height" 0.6mm
GATE 1 59 0
STM32WBA55UGI7
A1 0 U VSS_SMPS
A2 0 U PB14
A3 0 U PA10
A4 0 U VDD_RFPA
A5 0 U OSC__OUT
A6 0 U VDDRF
A7 0 U VSSRF_1
A8 0 U RF
B1 0 U VDD_SMPS
B2 0 U PB13
B3 0 U PA9
B4 0 U VDD_HPA
B5 0 U OSC_IN
B6 0 U VDD_ANA
B7 0 U VSSRF_2
B8 0 U NRST
C1 0 U VLX_SMPS
C2 0 U PB12
C3 0 U VDD11
C6 0 U VDD_1
C7 0 U PH3__BOOT0
C8 0 U PB15
D1 0 U PA8
D2 0 U PB11
D4 0 U VSS_1
D5 0 U VSS_2
D6 0 U VDD_2
D7 0 U PB0
D8 0 U PB1
E1 0 U PA6
E2 0 U PA7
E3 0 U VSS_3
E4 0 U VDD_3
E5 0 U VSS_4
E7 0 U PB2
E8 0 U PA11
F1 0 U VDDA
F2 0 U VSSA
F3 0 U PA5
F5 0 U VDD_4
F6 0 U PA14
F7 0 U PA12
F8 0 U PA13
G1 0 U PA4
G2 0 U PA3
G3 0 U PA2
G4 0 U PC15__OSC32__OUT
G5 0 U PC13
G6 0 U PB6
G7 0 U PB3
G8 0 U PA15
H1 0 U PA0
H2 0 U PA1
H3 0 U PB9
H4 0 U PC14__OSC32__IN
H5 0 U PB8
H6 0 U PB7
H7 0 U PB5
H8 0 U PB4

*END*
*REMARK* SamacSys ECAD Model
20862026/2063538/2.50/59/2/Integrated Circuit
