*PADS-LIBRARY-PART-TYPES-V9*

MCP9808-E_MS SOP65P490X110-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.12.50.24
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP9808-E/MS
"Mouser Part Number" 579-MCP9808-E/MS
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP9808-E-MS?qs=fgHA1UgJI8CbPdrkP5zjqQ%3D%3D
"Arrow Part Number" MCP9808-E/MS
"Arrow Price/Stock" https://www.arrow.com/en/products/mcp9808-ems_2/microchip-technology.html?utm_currency=USD&region=nac
"Description" +/-0.5C Maximum Accuracy Digital Temperature Sensor
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA18/383780.pdf
"Geometry.Height" 1.1mm
GATE 1 8 0
MCP9808-E_MS
1 0 U SDA
2 0 U SCL
3 0 U ALERT
4 0 U GND
8 0 U VDD
7 0 U A0
6 0 U A1
5 0 U A2

*END*
*REMARK* SamacSys ECAD Model
237575/2063303/2.50/8/3/Integrated Circuit
