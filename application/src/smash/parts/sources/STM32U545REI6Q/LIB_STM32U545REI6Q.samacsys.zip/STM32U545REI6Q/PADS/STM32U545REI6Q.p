*PADS-LIBRARY-PART-TYPES-V9*

STM32U545REI6Q BGA64C50P8X8_500X500X60 I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.13.02.45
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32U545REI6Q
"Mouser Part Number" 511-STM32U545REI6Q
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32U545REI6Q?qs=amGC7iS6iy%2FmK2KWPnQZ9w%3D%3D
"Arrow Part Number" STM32U545REI6Q
"Arrow Price/Stock" https://www.arrow.com/en/products/stm32u545rei6q/stmicroelectronics?utm_currency=USD&region=nac
"Description" Ultra-low-power Arm Cortex-M33 MCU+TrustZone+FPU, 240 DMPIS, 512 KB flash memory, 274 KB SRAM, crypto
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32u545ce.pdf
"Geometry.Height" 0.6mm
GATE 1 64 0
STM32U545REI6Q
A1 0 U VDD_1
A2 0 U VDD11_1
A3 0 U PH3-BOOT0
A4 0 U PB6
A5 0 U PB3
A6 0 U PD2
A7 0 U PC10
A8 0 U VDD_2
B1 0 U VBAT
B2 0 U VSS_1
B3 0 U PC13
B4 0 U PB4
B5 0 U PC11
B6 0 U PC12
B7 0 U VSS_2
B8 0 U VDDUSB
C1 0 U PC14-OSC32_IN
C2 0 U PC15-OSC32_OUT
C3 0 U PB8
C4 0 U PA15
C5 0 U PA14
C6 0 U PA13
C7 0 U PA12
C8 0 U PA11
D1 0 U PH0-OSC_IN
D2 0 U PH1-OSC_OUT
D3 0 U PB7
D4 0 U PB5
D5 0 U PA10
D6 0 U PA9
D7 0 U PA8
D8 0 U PC9
E1 0 U NRST
E2 0 U PC0
E3 0 U PC1
E4 0 U PC2
E5 0 U PA0
E6 0 U PB14
E7 0 U PC7
E8 0 U PC8
F1 0 U VSSA
F2 0 U PC3
F3 0 U PA1
F4 0 U PA4
F5 0 U PA6
F6 0 U PB10
F7 0 U PB15
F8 0 U PC6
G1 0 U VDDA
G2 0 U PA2
G3 0 U PA5
G4 0 U PB2
G5 0 U PB1
G6 0 U VSSSMPS
G7 0 U VSS_3
G8 0 U PB13
H1 0 U VDD_3
H2 0 U PA3
H3 0 U PA7
H4 0 U PB0
H5 0 U VLXSMPS
H6 0 U VDDSMPS
H7 0 U VDD11_2
H8 0 U VDD_4

*END*
*REMARK* SamacSys ECAD Model
18471979/2063538/2.50/64/2/Integrated Circuit
