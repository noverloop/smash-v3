*PADS-LIBRARY-PART-TYPES-V9*

RB160VAM-60 RB160VAM60 I DIO 9 1 0 0 0
TIMESTAMP 2026.11.21.22.35.36
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" RB160VAM-60
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/RB160VAM-60?qs=W0yvOO0ixfEX2AcHbxY23w%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 40A60V 60V Single 610mV1A 1A SMD-2 Schottky Barrier Diodes (SBD) ROHS
"Datasheet Link" https://www.mouser.ch/datasheet/2/348/ROHM_S_A0003728243_1-2561937.pdf
"Geometry.Height" 0.8mm
GATE 1 2 0
RB160VAM-60
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
15798367/2063473/2.50/2/3/Schottky Diode
