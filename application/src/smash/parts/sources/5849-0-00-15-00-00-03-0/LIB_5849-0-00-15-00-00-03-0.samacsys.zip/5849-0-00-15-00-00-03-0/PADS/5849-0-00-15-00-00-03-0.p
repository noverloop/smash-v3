*PADS-LIBRARY-PART-TYPES-V9*

5849-0-00-15-00-00-03-0 5849000150000030 I CON 9 1 0 0 0
TIMESTAMP 2026.11.21.14.31.58
"Manufacturer_Name" Mill-Max
"Manufacturer_Part_Number" 5849-0-00-15-00-00-03-0
"Mouser Part Number" 575-5849000150000030
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Mill-Max/5849-0-00-15-00-00-03-0?qs=8Wlm6%252BaMh8S1gD37W9VTOg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" PC Pin Terminal Connector Through Hole Gold 0.059" (1.50mm) Dia
"Datasheet Link" https://www.digikey.ph/en/products/detail/mill-max-manufacturing-corp/5849-0-00-15-00-00-03-0/17634857?srsltid=AfmBOorvF_9X0grZVRo5WmHOg7q81tHTJu295G-waKXyZNiSSW8Rs-GN
"Geometry.Height" 2.26mm
GATE 1 1 0
5849-0-00-15-00-00-03-0
1 0 U 1

*END*
*REMARK* SamacSys ECAD Model
18425899/2064551/2.50/1/3/Connector
