*PADS-LIBRARY-PART-TYPES-V9*

STM32WLE5JCI6 BGA73C50P9X9_500X500X60 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.16.07.23
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32WLE5JCI6
"Mouser Part Number" 511-STM32WLE5JCI6
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32WLE5JCI6?qs=xZ%2FP%252Ba9zWqZWgyuzFuSZUA%3D%3D
"Arrow Part Number" STM32WLE5JCI6
"Arrow Price/Stock" https://www.arrow.com/en/products/stm32wle5jci6/stmicroelectronics.html?utm_currency=USD&region=nac
"Description" Multiprotocol LPWAN 32-bit Arm Cortex-M4 MCUs, LoRa, (G)FSK, (G)MSK, BPSK, up to 256KB flash, 64KB SRAM
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32wle5c8.pdf
"Geometry.Height" 0.6mm
GATE 1 73 0
STM32WLE5JCI6
A1 0 U VSSSMPS
A2 0 U VDDSMPS
A4 0 U PA14
A5 0 U VDDA
A7 0 U VDD_1
A8 0 U VBAT
A9 0 U PA12
B1 0 U VLXSMPS
B2 0 U VFBSMPS
B3 0 U PA15
B4 0 U PB15
B5 0 U VREF+
B6 0 U PC14-_OSC32_IN
B7 0 U VSS_1
B8 0 U PA13
B9 0 U PA11
C1 0 U PB3
C2 0 U PB4
C3 0 U PB7
C4 0 U PB9
C5 0 U PC15-OSC32_OUT
C6 0 U PB14
C7 0 U PC13
C8 0 U PA10
D2 0 U PB5
D3 0 U PB8
D4 0 U PC2
D5 0 U PC3
D6 0 U PA0
D7 0 U PB13
D8 0 U PB2
D9 0 U VSS_2
E1 0 U PB6
E2 0 U VDD_2
E3 0 U VSS_3
E4 0 U PC5
E5 0 U PA9
E6 0 U PB12
E7 0 U PB1
E8 0 U VDDRF
E9 0 U VDD_3
F1 0 U PC1
F2 0 U PC0
F3 0 U PC4
F4 0 U PA6
F5 0 U NRST
F6 0 U PB0-VDD_TCXO
F7 0 U VDDRF1V55
F8 0 U OSC_OUT
G2 0 U PC6
G3 0 U PA1
G4 0 U PB11
G5 0 U VSS_4
G6 0 U VSSRF_1
G7 0 U VSSRF_2
G8 0 U VSSRF_3
G9 0 U OSC_IN
H1 0 U PA3
H2 0 U PA2
H3 0 U PA7
H4 0 U PB10
H5 0 U VDD_4
H6 0 U VSSRF_4
H7 0 U RFI_N
H8 0 U VDDPA
H9 0 U VR_PA
J1 0 U PA4
J2 0 U PA5
J3 0 U PA8
J5 0 U PH3
J6 0 U RFI_P
J8 0 U RFO_LP
J9 0 U RFO_HP

*END*
*REMARK* SamacSys ECAD Model
11389169/2063473/2.50/73/2/Integrated Circuit
