*PADS-LIBRARY-PART-TYPES-V9*

DRV8428EPWPR SOP65P640X120-17N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.31.21.48.13
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DRV8428EPWPR
"Mouser Part Number" 595-DRV8428EPWPR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DRV8428EPWPR?qs=81r%252BiQLm7BQM1fLIOdEEqA%3D%3D
"Arrow Part Number" DRV8428EPWPR
"Arrow Price/Stock" https://www.arrow.com/en/products/drv8428epwpr/texas-instruments?region=nac
"Description" DRV8428EPWPR
"Datasheet Link" https://www.ti.com/lit/ds/symlink/drv8428e.pdf
"Geometry.Height" 1.2mm
GATE 1 17 0
DRV8428EPWPR
1 0 U VM
2 0 U PGND
3 0 U AOUT1
4 0 U AOUT2
5 0 U BOUT2
6 0 U BOUT1
7 0 U GND
8 0 U DVDD
17 0 U EP
16 0 U NSLEEP
15 0 U AEN
14 0 U APH
13 0 U BEN
12 0 U BPH
11 0 U DECAY/TOFF
10 0 U VREFA
9 0 U VREFB

*END*
*REMARK* SamacSys ECAD Model
13475101/2063538/2.50/17/3/Integrated Circuit
