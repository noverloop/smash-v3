*PADS-LIBRARY-PART-TYPES-V9*

BSS138AKM-QYL BSS138AKMQYL I TRX 9 1 0 0 0
TIMESTAMP 2026.11.21.09.35.57
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" BSS138AKM-QYL
"Mouser Part Number" 771-BSS138AKM-QYL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/BSS138AKM-QYL?qs=wT7LY0lnAe1Y9Jh16X3Z%2Fg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" BSS138AKM-Q - 60 V, N-channel Trench MOSFET
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/BSS138AKM-Q.pdf
"Geometry.Height" 0.5mm
GATE 1 3 0
BSS138AKM-QYL
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
19374512/2063538/2.50/3/2/MOSFET (N-Channel)
