*PADS-LIBRARY-PART-TYPES-V9*

TPS259621DDAR SOIC127P600X170-9N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.23.47.59
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS259621DDAR
"Mouser Part Number" 595-TPS259621DDAR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS259621DDAR?qs=T3oQrply3y9R%252BQyO5xEAQg%3D%3D
"Arrow Part Number" TPS259621DDAR
"Arrow Price/Stock" https://www.arrow.com/en/products/tps259621ddar/texas-instruments?utm_currency=USD&region=nac
"Description" Texas Instruments 2.7 to 19 V, 0.13 to 2A, 85-m+? eFuse with accurate current monitor and fast overvoltage protection 8-SO PowerPAD -40 to 125
"Datasheet Link" http://www.ti.com/lit/ds/symlink/tps2596.pdf
"Geometry.Height" 1.7mm
GATE 1 9 0
TPS259621DDAR
1 0 U GND_1
2 0 U DVDT
3 0 U EN/UVLO
4 0 U IN
9 0 U GND_2
8 0 U OVLO/OVCSEL
7 0 U ILM
6 0 U \FLT
5 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
2426856/2063303/2.50/9/3/Integrated Circuit
