*PADS-LIBRARY-PART-TYPES-V9*

LMV331IDBVR SOT95P280X145-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.21.03.31
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMV331IDBVR
"Mouser Part Number" 595-LMV331IDBVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMV331IDBVR?qs=IF4wzcbwb3o4H8VE32EsDw%3D%3D
"Arrow Part Number" LMV331IDBVR
"Arrow Price/Stock" https://www.arrow.com/en/products/lmv331idbvr/texas-instruments?utm_currency=USD&region=nac
"Description" Texas Instruments LMV331IDBVR Comparator, Open Collector O/P, 3 V, 5 V 5-Pin SOT-23
"Datasheet Link" http://www.ti.com/lit/gpn/lmv331
"Geometry.Height" 1.45mm
GATE 1 5 0
LMV331IDBVR
1 0 U 1IN+
2 0 U GND
3 0 U 1IN-
4 0 U OUT
5 0 U VCC+

*END*
*REMARK* SamacSys ECAD Model
414995/2063303/2.50/5/3/Integrated Circuit
