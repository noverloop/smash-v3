*PADS-LIBRARY-PART-TYPES-V9*

IHLP2020BZER100M01 INDPM5552X200N I IND 9 1 0 0 0
TIMESTAMP 2026.11.22.17.14.36
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" IHLP2020BZER100M01
"Mouser Part Number" 70-IHLP2020BZER100M0
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Dale/IHLP2020BZER100M01?qs=ZAjGDd5n2aH5Lxf04Dpbtg%3D%3D
"Arrow Part Number" IHLP2020BZER100M01
"Arrow Price/Stock" https://www.arrow.com/en/products/ihlp2020bzer100m01/vishay?region=europe
"Description" Vishay IHLP2020BZ-01 Series Shielded Wire-wound SMD Inductor 10 uH +/-20% 4A Idc
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA11/2193762.pdf
"Geometry.Height" 2mm
GATE 1 2 0
IHLP2020BZER100M01
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
399891/2064551/2.50/2/4/Inductor
