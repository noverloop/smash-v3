*PADS-LIBRARY-PART-TYPES-V9*

DMN6075SQ-7 SOT96P240X110-3N I TRX 9 1 0 0 0
TIMESTAMP 2026.06.11.15.08.12
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" DMN6075SQ-7
"Mouser Part Number" 621-DMN6075SQ-7
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/DMN6075SQ-7?qs=OTrKUuiFdkZBTPnT%2F2GqPA%3D%3D
"Arrow Part Number" DMN6075SQ-7
"Arrow Price/Stock" https://www.arrow.com/en/products/dmn6075sq-7/diodes-incorporated?utm_currency=USD&region=nac
"Description" MOSFET MOSFET BVDSS: 41V 60V SOT23 T&R 3K
"Datasheet Link" https://www.diodes.com//assets/Datasheets/DMN6075SQ.pdf
"Geometry.Height" 1.1mm
GATE 1 3 0
DMN6075SQ-7
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
8072256/2063538/2.50/3/2/MOSFET (N-Channel)
