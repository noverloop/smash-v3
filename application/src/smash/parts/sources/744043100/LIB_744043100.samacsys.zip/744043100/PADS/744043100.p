*PADS-LIBRARY-PART-TYPES-V9*

744043100 INDPM4848X280N I IND 9 1 0 0 0
TIMESTAMP 2026.05.20.15.47.28
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 744043100
"Mouser Part Number" 710-744043100
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/744043100?qs=PGXP4M47uW67U3yLBymoaw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" WE-TPC SMT Shielded Tiny Power Inductor Size 4828; L = 10 H ; IR = 1.19 A; Isat = 1 A; RDC = 110 m
"Datasheet Link" https://www.we-online.com/catalog/datasheet/744043100.pdf
"Geometry.Height" 2.8mm
GATE 1 2 0
744043100
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
267846/2064551/2.50/2/2/Inductor
