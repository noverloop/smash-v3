PCBNEW-LibModule-V1  2026-11-21 11:51:11
# encoding utf-8
Units mm
$INDEX
QFN50P600X600X100-37N-D
$EndINDEX
$MODULE QFN50P600X600X100-37N-D
Po 0 0 0 15 6b0185af 00000000 ~~
Li QFN50P600X600X100-37N-D
Cd M2 LEGACY
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "QFN50P600X600X100-37N-D"
DS -3.625 -3.625 3.625 -3.625 0.05 24
DS 3.625 -3.625 3.625 3.625 0.05 24
DS 3.625 3.625 -3.625 3.625 0.05 24
DS -3.625 3.625 -3.625 -3.625 0.05 24
DS -3 -3 3 -3 0.1 24
DS 3 -3 3 3 0.1 24
DS 3 3 -3 3 0.1 24
DS -3 3 -3 -3 0.1 24
DS -3 -2.5 -2.5 -3 0.1 24
DC -3.375 -2.75 -3.25 -2.75 0.254 21
$PAD
Po -2.8 -2
Sh "1" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -1.5
Sh "2" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -1
Sh "3" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -0.5
Sh "4" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 0
Sh "5" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 0.5
Sh "6" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 1
Sh "7" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 1.5
Sh "8" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 2
Sh "9" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 2.8
Sh "10" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 2.8
Sh "11" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 2.8
Sh "12" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 2.8
Sh "13" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 2.8
Sh "14" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 2.8
Sh "15" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 2.8
Sh "16" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 2.8
Sh "17" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 2.8
Sh "18" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 2
Sh "19" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 1.5
Sh "20" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 1
Sh "21" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 0.5
Sh "22" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 0
Sh "23" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -0.5
Sh "24" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -1
Sh "25" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -1.5
Sh "26" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -2
Sh "27" R 0.3 1.15 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -2.8
Sh "28" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -2.8
Sh "29" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 -2.8
Sh "30" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -2.8
Sh "31" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 -2.8
Sh "32" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -2.8
Sh "33" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 -2.8
Sh "34" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -2.8
Sh "35" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -2.8
Sh "36" R 0.3 1.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0
Sh "37" R 3.85 3.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE QFN50P600X600X100-37N-D
$EndLIBRARY
