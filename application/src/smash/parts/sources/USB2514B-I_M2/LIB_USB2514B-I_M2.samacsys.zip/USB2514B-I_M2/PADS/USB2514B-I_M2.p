*PADS-LIBRARY-PART-TYPES-V9*

USB2514B-I_M2 QFN50P600X600X100-37N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.21.11.51.11
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" USB2514B-I/M2
"Mouser Part Number" 579-USB2514B-I/M2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/USB2514B-I-M2?qs=uus7iwvxYD%252BYUekNs2mWlw%3D%3D
"Arrow Part Number" USB2514B-I/M2
"Arrow Price/Stock" https://www.arrow.com/en/products/usb2514b-im2/microchip-technology.html?utm_currency=USD&region=asia
"Description" Microchip USB2514B-I/M2, USB Controller, USB 2.0, 3.3 V, 36-Pin SQFN
"Datasheet Link" http://ww1.microchip.com/downloads/en/DeviceDoc/00001692C.pdf
"Geometry.Height" 1mm
GATE 1 37 0
USB2514B-I_M2
1 0 U USBDM_DN_1_/PRT_DIS_M1
2 0 U USBDP_DM/PRT_DIS_P1
3 0 U USBDM_DN2/PRT_DIS_M2
4 0 U USBDP_DN2/PR_T_D1S_P2
5 0 U VDDA33_1
6 0 U NC_1
7 0 U NC_2
8 0 U NC_3
9 0 U NC_4
10 0 U VDDA33_2
11 0 U TEST
12 0 U PRTPWR1/BC_EN1
13 0 U OCS_N1
14 0 U CRFILT
15 0 U VDD33_1
16 0 U PRTPWR2/BC_EN2
17 0 U OCS_N2
18 0 U NC_5
27 0 U VBUS_DET
26 0 U RESET_N
25 0 U HS_IND/CFG_SEL1
24 0 U SC_L/SM_BCL_K/C_FGSEL0
23 0 U VDD33_2
22 0 U SDA/SMBDATA/NON_REM1
21 0 U NC_8
20 0 U NC_7
19 0 U NC_6
NUMBER 0 U NAME
36 0 U VDDA33_4
35 0 U RBIAS
34 0 U PLLFILT
33 0 U XTALIN/CLKIN
32 0 U XTALOUT
31 0 U USBDP_UP
30 0 U USBDM_UP
29 0 U VDDA33_3
28 0 U SUSP_IND/LOCAL_PWR/NON_REM0

*END*
*REMARK* SamacSys ECAD Model
531688/2063538/2.50/37/4/Integrated Circuit
