*PADS-LIBRARY-PART-TYPES-V9*

TPS62088YFPR BGA6C40P2X3_80X120X50 I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.22.57.06
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS62088YFPR
"Mouser Part Number" 595-TPS62088YFPR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS62088YFPR?qs=W0yvOO0ixfGNKStxFK6MHQ%3D%3D
"Arrow Part Number" TPS62088YFPR
"Arrow Price/Stock" https://www.arrow.com/en/products/tps62088yfpr/texas-instruments?utm_currency=USD&region=nac
"Description" 2.4V-5.5V input, tiny 6-pin 3A step-down converter in 1.2-mm x 0.8-mm WCSP
"Datasheet Link" http://www.ti.com/lit/gpn/tps62088
"Geometry.Height" 0.5mm
GATE 1 6 0
TPS62088YFPR
A1 0 U EN
A2 0 U VIN
B1 0 U PG
B2 0 U SW
C1 0 U FB
C2 0 U GND

*END*
*REMARK* SamacSys ECAD Model
1026722/2063473/2.50/6/3/Integrated Circuit
