*PADS-LIBRARY-PART-TYPES-V9*

DSC1001CI5-008.0000 DSC1001CI50080000 I OSC 9 1 0 0 0
TIMESTAMP 2026.05.19.16.49.10
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" DSC1001CI5-008.0000
"Mouser Part Number" 579-001CI50080000
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/DSC1001CI5-008.0000?qs=1mbolxNpo8fUDrvmuRVITg%3D%3D
"Arrow Part Number" DSC1001CI5-008.0000
"Arrow Price/Stock" https://www.arrow.com/en/products/dsc1001ci5-008.0000/microchip-technology
"Description" MEMS OSCILLATOR, LOW POWER, -4
"Datasheet Link" https://www.arrow.com/en/products/dsc1001ci5-008.0000/microchip-technology
"Geometry.Height" 0.9mm
GATE 1 4 0
DSC1001CI5-008.0000
1 0 U STANDBY#
2 0 U GND
3 0 U OUT
4 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
1295592/2063303/2.50/4/4/Crystal or Oscillator
