*PADS-LIBRARY-PART-TYPES-V9*

SFH203FA SFH203FA I DIO 9 1 0 0 0
TIMESTAMP 2026.05.25.14.13.50
"Manufacturer_Name" ams OSRAM
"Manufacturer_Part_Number" SFH203FA
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" SFH203FA
"Arrow Price/Stock" https://www.arrow.com/en/products/sfh-203-fa/ams-osram?utm_currency=USD&region=europe
"Description" Photodiode PIN Chip 900nm 0.59A/W Sensitivity 2-Pin T-1 3/4 T/R
"Datasheet Link" https://www.osram.com/ecat/com/en/class_pim_web_catalog_103489/global/prd_pim_device_2219555/
"Geometry.Height" 8.9mm
GATE 1 2 0
SFH203FA
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
1175249/2063538/2.50/2/4/LED
