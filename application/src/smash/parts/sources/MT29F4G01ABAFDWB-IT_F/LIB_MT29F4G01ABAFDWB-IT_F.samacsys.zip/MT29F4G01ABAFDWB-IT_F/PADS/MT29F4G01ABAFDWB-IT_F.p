*PADS-LIBRARY-PART-TYPES-V9*

MT29F4G01ABAFDWB-IT_F SON127P800X600X65-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.20.10.35
"Manufacturer_Name" Micron
"Manufacturer_Part_Number" MT29F4G01ABAFDWB-IT:F
"Mouser Part Number" 340-359563
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Micron/MT29F4G01ABAFDWB-ITF?qs=wUXugUrL1qwrjb7To7JPbA%3D%3D
"Arrow Part Number" MT29F4G01ABAFDWB-IT:F
"Arrow Price/Stock" null?region=nac
"Description" NAND Flash SLC 4G 4GX1 UPDFN IT M70A
"Datasheet Link" https://www.farnell.com/datasheets/3151403.pdf
"Geometry.Height" 0.65mm
GATE 1 8 0
MT29F4G01ABAFDWB-IT_F
1 0 U CS#
2 0 U SO/IO1
3 0 U WP#/IO2
4 0 U VSS
8 0 U VCC
7 0 U HOLD#/IO3
6 0 U SCK
5 0 U SI/IO0

*END*
*REMARK* SamacSys ECAD Model
1589711/2063303/2.50/8/3/Integrated Circuit
