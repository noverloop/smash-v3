*PADS-LIBRARY-PART-TYPES-V9*

nRF21540-QDAA-R7 QFN65P400X400X95-17N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.14.00.07.40
"Manufacturer_Name" Nordic Semiconductor
"Manufacturer_Part_Number" nRF21540-QDAA-R7
"Mouser Part Number" 949-NRF21540-QDAA-R7
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nordic-Semiconductor/nRF21540-QDAA-R7?qs=xZ%2FP%252Ba9zWqZdudwModMGkg%3D%3D
"Arrow Part Number" NRF21540-QDAA-R7
"Arrow Price/Stock" https://www.arrow.com/en/products/nrf21540-qdaa-r7/nordic-semiconductor?region=nac
"Description" RF Front End Range Extender FEM +13 dB RX gain
"Datasheet Link" https://ms.componentsearchengine.com/Datasheets/2/NRF21540-QDAA-R7.pdf
"Geometry.Height" 0.95mm
GATE 1 17 0
nRF21540-QDAA-R7
1 0 U VSS_1
2 0 U ANT1
3 0 U ANT2
4 0 U MODE
5 0 U VDD_1
6 0 U VDD_2
7 0 U RX_EN
8 0 U ANT_SEL
12 0 U SCK
11 0 U PDN
10 0 U TRE
9 0 U TX_EN
17 0 U EP
16 0 U VSS_2
15 0 U CSN
14 0 U MISO
13 0 U MOSI

*END*
*REMARK* SamacSys ECAD Model
11442088/2063538/2.50/17/3/Integrated Circuit
