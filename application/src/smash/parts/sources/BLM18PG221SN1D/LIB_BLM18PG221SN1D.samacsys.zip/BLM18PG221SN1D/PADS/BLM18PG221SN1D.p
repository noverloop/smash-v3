*PADS-LIBRARY-PART-TYPES-V9*

BLM18PG221SN1D BLM18SP221SN1B I ANA 9 1 0 0 0
TIMESTAMP 2026.11.16.14.40.31
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" BLM18PG221SN1D
"Mouser Part Number" 81-BLM18PG221SN1D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/BLM18PG221SN1D?qs=uSeJpk%2F8In3JS43lpC2ejg%3D%3D
"Arrow Part Number" BLM18PG221SN1D
"Arrow Price/Stock" https://www.arrow.com/en/products/blm18pg221sn1d/murata-manufacturing?utm_currency=USD&region=nac
"Description" BL Chip Ferrite Bead 0603
"Datasheet Link" http://www.murata.com/~/media/webrenewal/support/library/catalog/products/emc/emifil/c31e.ashx?la=en-gb
"Geometry.Height" 0.95mm
GATE 1 2 0
BLM18PG221SN1D
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
12867471/2063538/2.50/2/5/Ferrite Bead
