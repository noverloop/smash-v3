*PADS-LIBRARY-PART-TYPES-V9*

ISM330DLCTR LGA-14_1 I ANA 8 1 0 0 0
TIMESTAMP 2026.11.22.12.51.58
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" ISM330DLCTR
"Mouser Part Number" 511-ISM330DLCTR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/ISM330DLCTR?qs=HXFqYaX1Q2xJsRh9qTmUlw%3D%3D
"Arrow Part Number" ISM330DLCTR
"Arrow Price/Stock" https://www.arrow.com/en/products/ism330dlctr/stmicroelectronics.html?utm_currency=USD&region=nac
"Description" iNEMO 6-axis IMU: 3-axis accelerometer and 3-axis gyroscope with digital output for industrial applications
"Datasheet Link" https://www.st.com/resource/en/datasheet/ism330dlc.pdf
GATE 1 14 0
ISM330DLCTR
1 0 U SDO/SA0
2 0 U SDX
3 0 U SCX
4 0 U INT1
5 0 U VDDIO
6 0 U GND_1
7 0 U GND_2
8 0 U VDD
9 0 U INT2
10 0 U OCS_AUX
11 0 U SD0_AUX
12 0 U CS
13 0 U SCL
14 0 U SDA

*END*
*REMARK* SamacSys ECAD Model
824555/2063303/2.50/14/2/Integrated Circuit
