PCBNEW-LibModule-V1  2026-11-22 12:51:58
# encoding utf-8
Units mm
$INDEX
LGA-14_1
$EndINDEX
$MODULE LGA-14_1
Po 0 0 0 15 6b02e56e 00000000 ~~
Li LGA-14_1
Cd LGA-14_1
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 -0.35682 -0.05775 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 -0.35682 -0.05775 1.27 1.27 0 0.254 N I 21 N "LGA-14_1"
DS -1.5 -1.25 1.5 -1.25 0.2 24
DS 1.5 -1.25 1.5 1.25 0.2 24
DS 1.5 1.25 -1.5 1.25 0.2 24
DS -1.5 1.25 -1.5 -1.25 0.2 24
DC -1.815 -0.756 -1.827 -0.756 0.254 21
$PAD
Po -1.15 -0.75
Sh "1" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.15 -0.25
Sh "2" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.15 0.25
Sh "3" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.15 0.75
Sh "4" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 0.9
Sh "5" R 0.3 0.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0.9
Sh "6" R 0.3 0.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 0.9
Sh "7" R 0.3 0.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.15 0.75
Sh "8" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.15 0.25
Sh "9" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.15 -0.25
Sh "10" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.15 -0.75
Sh "11" R 0.3 0.6 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -0.9
Sh "12" R 0.3 0.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 -0.9
Sh "13" R 0.3 0.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -0.9
Sh "14" R 0.3 0.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE LGA-14_1
$EndLIBRARY
