*PADS-LIBRARY-PART-TYPES-V9*

UJ20-C-V-G-SMT-23B-P16-TR-X5 UJ20CVGSMT23BP16TRX5 I CON 9 1 0 0 0
TIMESTAMP 2026.11.19.16.03.37
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" UJ20-C-V-G-SMT-23B-P16-TR-X5
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Type C, USB 2.0, 480 Mbps, 20 Vdc, 5 A, Vertical, Surface Mount, Gold Flash, IPX5, USB Receptacle
"Datasheet Link" https://www.sameskydevices.com/product/resource/uj20-c-v-g-smt-23b-p16-tr-x5.pdf
"Geometry.Height" 6.2mm
GATE 1 20 0
UJ20-C-V-G-SMT-23B-P16-TR-X5
A1 0 U GND_1
A4 0 U VBUS_1
A5 0 U CC1
A6 0 U DP1
A7 0 U DN1
A8 0 U SBU1
A9 0 U VBUS_2
A12 0 U GND_2
B1 0 U GND_3
B4 0 U VBUS_3
B5 0 U CC2
B6 0 U DP2
B7 0 U DN2
B8 0 U SBU2
B9 0 U VBUS_4
B12 0 U GND_4
MP1 0 U MP1
MP2 0 U MP2
MP3 0 U MP3
MP4 0 U MP4

*END*
*REMARK* SamacSys ECAD Model
22234639/2064551/2.50/20/2/Connector
