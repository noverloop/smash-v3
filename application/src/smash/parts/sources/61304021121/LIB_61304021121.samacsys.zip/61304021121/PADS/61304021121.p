*PADS-LIBRARY-PART-TYPES-V9*

61304021121 HDRV40W64P254X254_2X20_5080X508X869P I CON 9 1 0 0 0
TIMESTAMP 2026.11.22.18.27.21
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 61304021121
"Mouser Part Number" 710-61304021121
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/61304021121?qs=PhR8RmCirEYWKI5WqdDUyg%3D%3D
"Arrow Part Number" 61304021121
"Arrow Price/Stock" null?utm_currency=USD&region=asia
"Description" WR-PHD 2.54 mm Dual Row Pin Header 40 pins, dual Row , straight, gold plating
"Datasheet Link" https://www.we-online.com/catalog/datasheet/61304021121.pdf
"Geometry.Height" 8.69mm
GATE 1 40 0
61304021121
1 0 U 1
3 0 U 3
5 0 U 5
7 0 U 7
9 0 U 9
11 0 U 11
13 0 U 13
15 0 U 15
17 0 U 17
19 0 U 19
21 0 U 21
23 0 U 23
25 0 U 25
27 0 U 27
29 0 U 29
31 0 U 31
33 0 U 33
35 0 U 35
37 0 U 37
39 0 U 39
2 0 U 2
4 0 U 4
6 0 U 6
8 0 U 8
10 0 U 10
12 0 U 12
14 0 U 14
16 0 U 16
18 0 U 18
20 0 U 20
22 0 U 22
24 0 U 24
26 0 U 26
28 0 U 28
30 0 U 30
32 0 U 32
34 0 U 34
36 0 U 36
38 0 U 38
40 0 U 40

*END*
*REMARK* SamacSys ECAD Model
233990/2065276/2.50/40/2/Connector
