*PADS-LIBRARY-PART-TYPES-V9*

TPS61085PW SOP65P490X110-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.20.01.26
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS61085PW
"Mouser Part Number" 595-TPS61085PW
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS61085PW?qs=59Rn2Bt6jP2NHSEIImGNRg%3D%3D
"Arrow Part Number" TPS61085PW
"Arrow Price/Stock" https://www.arrow.com/en/products/tps61085pw/texas-instruments?region=nac
"Description" Conv DC-DC Single-OUT Step Up TPS61085PW, Boost Converter, Step Up 2A Adjustable, 2.8  18.5 V, 1200 kHz, 8-Pin TSSOP
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-45/DSA-2073.pdf
"Geometry.Height" 1.1mm
GATE 1 8 0
TPS61085PW
1 0 U COMP
2 0 U FB
3 0 U EN
4 0 G PGND
8 0 U SS
7 0 U FREQ
6 0 L IN
5 0 U SW

*END*
*REMARK* SamacSys ECAD Model
256501/2063538/2.50/8/4/Integrated Circuit
