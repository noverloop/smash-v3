*PADS-LIBRARY-PART-TYPES-V9*

T521V476M016ATE070 T521V I CAP 9 1 0 0 0
TIMESTAMP 2026.11.22.13.02.57
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" T521V476M016ATE070
"Mouser Part Number" 80-T521V476M016ATE70
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=80-T521V476M016ATE70
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" SMD, Polymer, Molded, Low Profile/ESR, NonCombustible
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_T2076_T52X-530
"Geometry.Height" 1.9mm
GATE 1 2 0
T521V476M016ATE070
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
1089974/2063538/2.50/2/2/Capacitor Polarised
