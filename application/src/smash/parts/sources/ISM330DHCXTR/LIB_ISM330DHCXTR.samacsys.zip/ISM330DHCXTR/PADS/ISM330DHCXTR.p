*PADS-LIBRARY-PART-TYPES-V9*

ISM330DHCXTR LSM6DS3USTR I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.18.24.10
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" ISM330DHCXTR
"Mouser Part Number" 511-ISM330DHCXTR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/ISM330DHCXTR?qs=%252B6g0mu59x7Jv2Xps2dM6Xw%3D%3D
"Arrow Part Number" ISM330DHCXTR
"Arrow Price/Stock" https://www.arrow.com/en/products/ism330dhcxtr/stmicroelectronics?utm_currency=USD&region=nac
"Description" iNEMO inertial module with embedded Machine Learning Core: always-on 3D accelerometer and 3D gyroscope with digital output for industrial applications
"Datasheet Link" https://www.st.com/resource/en/datasheet/ism330dhcx.pdf
"Geometry.Height" 0.86mm
GATE 1 14 0
ISM330DHCXTR
1 0 U SDO/SA0
2 0 U SDX
3 0 U SCX
4 0 U INT1
5 0 U VDDIO
6 0 U GND_1
7 0 U GND_2
8 0 U VDD
9 0 U INT2
10 0 U OCS_AUX
11 0 U SDO_AUX
12 0 U CS
13 0 U SCL
14 0 U SDA

*END*
*REMARK* SamacSys ECAD Model
2413526/2063538/2.50/14/2/Integrated Circuit
