*PADS-LIBRARY-PART-TYPES-V9*

T520W107M006ATE040 T520W I CAP 9 1 0 0 0
TIMESTAMP 2026.11.21.21.20.05
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" T520W107M006ATE040
"Mouser Part Number" 80-T520W107M6ATE40
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/T520W107M006ATE040?qs=AHS6Mz2dKxMoKG2NoQ4jpw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" SMD, Polymer, Molded, Low Profile/ESR, NonCombustible
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_T2076_T52X-530
"Geometry.Height" 1.5mm
GATE 1 2 0
T520W107M006ATE040
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
975249/2064551/2.50/2/2/Capacitor Polarised
