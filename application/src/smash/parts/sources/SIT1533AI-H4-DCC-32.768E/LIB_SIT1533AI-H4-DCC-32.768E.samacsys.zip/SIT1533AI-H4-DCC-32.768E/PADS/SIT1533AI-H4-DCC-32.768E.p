*PADS-LIBRARY-PART-TYPES-V9*

SIT1533AI-H4-DCC-32.768E SIT1533AIH4DCC32768E I OSC 9 1 0 0 0
TIMESTAMP 2026.11.20.21.00.45
"Manufacturer_Name" SiTime
"Manufacturer_Part_Number" SIT1533AI-H4-DCC-32.768E
"Mouser Part Number" 788-1533AIH4DCC32.76
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/SiTime/SiT1533AI-H4-DCC-32.768E?qs=5SDzjInHUKoUZz9ePr9JwA%3D%3D
"Arrow Part Number" SIT1533AI-H4-DCC-32.768E
"Arrow Price/Stock" https://www.arrow.com/en/products/sit1533ai-h4-dcc-32-768e/sitime.html?utm_currency=USD&region=nac
"Description" Standard Clock Oscillators 32.768KHz R2R LVCMOS -40 to 85C 100ppm
"Datasheet Link" https://www.sitime.com/datasheet/SiT1533
"Geometry.Height" 0.6mm
GATE 1 4 0
SIT1533AI-H4-DCC-32.768E
1 0 U NC
2 0 U GND
3 0 U CLK_OUT
4 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
851508/2064551/2.50/4/4/Crystal or Oscillator
