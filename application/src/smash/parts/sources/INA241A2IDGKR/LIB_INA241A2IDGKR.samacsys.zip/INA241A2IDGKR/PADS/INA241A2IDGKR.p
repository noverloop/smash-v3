*PADS-LIBRARY-PART-TYPES-V9*

INA241A2IDGKR SOP65P490X110-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.21.11.52.55
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" INA241A2IDGKR
"Mouser Part Number" 595-INA241A2IDGKR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/INA241A2IDGKR?qs=Imq1NPwxi772hZtuitx1Tg%3D%3D
"Arrow Part Number" INA241A2IDGKR
"Arrow Price/Stock" https://www.arrow.com/en/products/ina241a2idgkr/texas-instruments?utm_currency=USD&region=nac
"Description" Current Sense Amplifier 1 Circuit Single-Ended 8-VSSOP
"Datasheet Link" https://www.ti.com/lit/ds/symlink/ina241a.pdf?ts=1698648582718&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FINA241A%253Futm_source%253Dgoogle%2526utm_medium%253Dcpc%2526utm_campaign%253Dasc-amps-null-44700045336317476_prodfolderdynamic-cpc-pf-go
"Geometry.Height" 1.1mm
GATE 1 8 0
INA241A2IDGKR
1 0 U IN-
2 0 U GND
3 0 U REF2
4 0 U NC
8 0 U IN+
7 0 U REF1
6 0 U VS
5 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
19722870/2063303/2.50/8/3/Integrated Circuit
