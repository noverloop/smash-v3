*PADS-LIBRARY-PART-TYPES-V9*

PAC1941T-1E_4MX QFN50P300X300X90-17N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.22.18.27.10
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" PAC1941T-1E/4MX
"Mouser Part Number" 579-PAC1941T-1E/4MX
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/PAC1941T-1E-4MX?qs=W%2FMpXkg%252BdQ4NeKHP0POqwQ%3D%3D
"Arrow Part Number" PAC1941T-1E/4MX
"Arrow Price/Stock" https://www.arrow.com/en/products/pac1941t-1e4mx/microchip-technology?region=nac
"Description" MICROCHIP - PAC1941T-1E/4MX - Power Monitor IC, Accumulator, 2.7 V to 5.5 V, VQFN-16, -40 C to 125 C
"Datasheet Link" https://ww1.microchip.com/downloads/aemDocuments/documents/MSLD/ProductDocuments/DataSheets/PAC194X-Family-Data-Sheet-DS20006543.pdf
"Geometry.Height" 0.9mm
GATE 1 17 0
PAC1941T-1E_4MX
1 0 U SLOW/\ALERT1
2 0 U VDD
3 0 U GND
4 0 U SCL
5 0 U SDA
6 0 U ADDRSEL
7 0 U SENSE3-
8 0 U SENSE3+
12 0 U SENSE1-
11 0 U SENSE1+
10 0 U SENSE4+
9 0 U SENSE4-
17 0 U EP
16 0 U \PWRDN
15 0 U GPIO/\ALERT2
14 0 U SENSE2-
13 0 U SENSE2+

*END*
*REMARK* SamacSys ECAD Model
15114002/2065276/2.50/17/0/Integrated Circuit
