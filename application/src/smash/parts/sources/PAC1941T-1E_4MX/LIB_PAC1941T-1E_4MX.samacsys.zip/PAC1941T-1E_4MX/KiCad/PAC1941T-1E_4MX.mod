PCBNEW-LibModule-V1  2026-11-22 18:27:10
# encoding utf-8
Units mm
$INDEX
QFN50P300X300X90-17N-D
$EndINDEX
$MODULE QFN50P300X300X90-17N-D
Po 0 0 0 15 6b0333fe 00000000 ~~
Li QFN50P300X300X90-17N-D
Cd 16-Lead Very Thin Quad Flat, No Lead Package (4MX)
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "QFN50P300X300X90-17N-D"
DS -2.1 -2.1 2.1 -2.1 0.05 24
DS 2.1 -2.1 2.1 2.1 0.05 24
DS 2.1 2.1 -2.1 2.1 0.05 24
DS -2.1 2.1 -2.1 -2.1 0.05 24
DS -1.5 -1.5 1.5 -1.5 0.1 24
DS 1.5 -1.5 1.5 1.5 0.1 24
DS 1.5 1.5 -1.5 1.5 0.1 24
DS -1.5 1.5 -1.5 -1.5 0.1 24
DS -1.5 -1 -1 -1.5 0.1 24
DC -1.85 -1.5 -1.725 -1.5 0.254 21
$PAD
Po -1.45 -0.75
Sh "1" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.45 -0.25
Sh "2" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.45 0.25
Sh "3" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.45 0.75
Sh "4" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 1.45
Sh "5" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 1.45
Sh "6" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 1.45
Sh "7" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 1.45
Sh "8" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.45 0.75
Sh "9" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.45 0.25
Sh "10" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.45 -0.25
Sh "11" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.45 -0.75
Sh "12" R 0.3 0.8 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.75 -1.45
Sh "13" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.25 -1.45
Sh "14" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.25 -1.45
Sh "15" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.75 -1.45
Sh "16" R 0.3 0.8 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0
Sh "17" R 1.2 1.2 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE QFN50P300X300X90-17N-D
$EndLIBRARY
