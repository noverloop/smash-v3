PCBNEW-LibModule-V1  2026-05-20 19:59:41
# encoding utf-8
Units mm
$INDEX
QFN40P650X650X90-57N-D
$EndINDEX
$MODULE QFN40P650X650X90-57N-D
Po 0 0 0 15 6a0e049d 00000000 ~~
Li QFN40P650X650X90-57N-D
Cd STPMIC25APQR
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "QFN40P650X650X90-57N-D"
DS -3.875 -3.875 3.875 -3.875 0.05 24
DS 3.875 -3.875 3.875 3.875 0.05 24
DS 3.875 3.875 -3.875 3.875 0.05 24
DS -3.875 3.875 -3.875 -3.875 0.05 24
DS -3.25 -3.25 3.25 -3.25 0.1 24
DS 3.25 -3.25 3.25 3.25 0.1 24
DS 3.25 3.25 -3.25 3.25 0.1 24
DS -3.25 3.25 -3.25 -3.25 0.1 24
DS -3.25 -2.85 -2.85 -3.25 0.1 24
DC -3.625 -3.2 -3.525 -3.2 0.254 21
$PAD
Po -3.2 -2.6
Sh "1" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 -2.2
Sh "2" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 -1.8
Sh "3" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 -1.4
Sh "4" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 -1
Sh "5" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 -0.6
Sh "6" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 -0.2
Sh "7" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 0.2
Sh "8" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 0.6
Sh "9" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 1
Sh "10" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 1.4
Sh "11" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 1.8
Sh "12" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 2.2
Sh "13" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.2 2.6
Sh "14" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.6 3.2
Sh "15" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.2 3.2
Sh "16" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.8 3.2
Sh "17" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.4 3.2
Sh "18" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 3.2
Sh "19" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.6 3.2
Sh "20" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.2 3.2
Sh "21" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.2 3.2
Sh "22" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.6 3.2
Sh "23" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 3.2
Sh "24" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.4 3.2
Sh "25" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.8 3.2
Sh "26" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.2 3.2
Sh "27" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.6 3.2
Sh "28" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 2.6
Sh "29" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 2.2
Sh "30" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 1.8
Sh "31" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 1.4
Sh "32" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 1
Sh "33" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 0.6
Sh "34" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 0.2
Sh "35" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -0.2
Sh "36" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -0.6
Sh "37" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -1
Sh "38" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -1.4
Sh "39" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -1.8
Sh "40" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -2.2
Sh "41" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.2 -2.6
Sh "42" R 0.2 0.85 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.6 -3.2
Sh "43" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.2 -3.2
Sh "44" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.8 -3.2
Sh "45" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.4 -3.2
Sh "46" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 -3.2
Sh "47" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.6 -3.2
Sh "48" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.2 -3.2
Sh "49" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.2 -3.2
Sh "50" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.6 -3.2
Sh "51" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 -3.2
Sh "52" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.4 -3.2
Sh "53" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.8 -3.2
Sh "54" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.2 -3.2
Sh "55" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.6 -3.2
Sh "56" R 0.2 0.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0
Sh "57" R 4.55 4.55 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE QFN40P650X650X90-57N-D
$EndLIBRARY
