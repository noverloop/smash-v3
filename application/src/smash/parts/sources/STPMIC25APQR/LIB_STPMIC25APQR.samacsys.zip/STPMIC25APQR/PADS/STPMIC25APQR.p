*PADS-LIBRARY-PART-TYPES-V9*

STPMIC25APQR QFN40P650X650X90-57N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.05.20.19.59.41
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STPMIC25APQR
"Mouser Part Number" 511-STPMIC25APQR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STPMIC25APQR?qs=jRuttqqUwMR8b%2FyHW8MhFQ%3D%3D
"Arrow Part Number" STPMIC25APQR
"Arrow Price/Stock" https://www.arrow.com/en/products/stpmic25apqr/stmicroelectronics?utm_currency=USD&region=nac
"Description" Highly integrated power management IC for micro processor units
"Datasheet Link" https://www.st.com/resource/en/datasheet/stpmic25.pdf
"Geometry.Height" 0.9mm
GATE 1 57 0
STPMIC25APQR
1 0 U PONKEYN
2 0 U LDO8OUT
3 0 U LDO78IN
4 0 U LDO7OUT
5 0 U LDO6OUT
6 0 U LDO56IN
7 0 U LDO5OUT
8 0 U INTLDO
9 0 U GNDLDO
10 0 U AGND
11 0 U VIN
12 0 U VBUS
13 0 U LDO4OUT
14 0 U LDO1OUT
15 0 U LDO12IN
16 0 U LDO2OUT
17 0 U VOUT4
18 0 U PGND4
19 0 U VLX4
20 0 U BUCK4IN
21 0 U VOUT3
22 0 U PGND3
23 0 U VLX3
24 0 U BUCK3IN
25 0 U BUCK2IN
26 0 U VLX2
27 0 U PGND2
28 0 U VOUT2
42 0 U VOUT1
41 0 U PGND1
40 0 U VLX1
39 0 U BUCK1IN
38 0 U BUCK5IN
37 0 U VLX5
36 0 U PGND5
35 0 U VOUT5
34 0 U SDA
33 0 U SCL
32 0 U INTN
31 0 U RSTN
30 0 U WAKEUPN
29 0 U VIO
57 0 U EP
56 0 U PWRCTRL1
55 0 U PWRCTRL2
54 0 U PWRCTRL3
53 0 U VOUT7
52 0 U PGND7
51 0 U VLX7
50 0 U BUCK7IN
49 0 U BUCK6IN
48 0 U VLX6
47 0 U PGND6
46 0 U VOUT6
45 0 U VREFDDR
44 0 U LDO3OUT
43 0 U LDO3IN

*END*
*REMARK* SamacSys ECAD Model
19514826/2063538/2.50/57/2/Integrated Circuit
