*PADS-LIBRARY-PART-TYPES-V9*

STM32WBA52CGU7TR QFN50P700X700X65-49N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.05.28.18.45.06
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32WBA52CGU7TR
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" IC RF TxRx + MCU Bluetooth Bluetooth v5.3 2.4GHz 48-UFQFN Exposed Pad , 1.71V ~ 3.6V , 7.39mA ~ 8mA, -40C ~ 85C (TA)
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32wba52ce.pdf
"Geometry.Height" 0.65mm
GATE 1 49 0
STM32WBA52CGU7TR
1 0 U PB12
2 0 U PB11
3 0 U PA8
4 0 U PA7
5 0 U PA6
6 0 U VDDA
7 0 U PA5
8 0 U PA3
9 0 U PB10
10 0 U PA2
11 0 U VDD_1
12 0 U PA1
13 0 U PA0
14 0 U PB9
15 0 U PB8
16 0 U PC15-OSC32_OUT
17 0 U PC14-OSC32_IN
18 0 U PC13
19 0 U PB7
20 0 U PB6
21 0 U PB5
22 0 U VDD_2
23 0 U PB4
24 0 U PB3
36 0 U NRST
35 0 U VDD_3
34 0 U PH3-BOOT0
33 0 U PB15
32 0 U PB0
31 0 U PB1
30 0 U PB2
29 0 U PA11
28 0 U PA12
27 0 U PA13
26 0 U PA14
25 0 U PA15
49 0 U VSS
48 0 U PB13
47 0 U PB14
46 0 U PA9
45 0 U PA10
44 0 U VCAP
43 0 U VDD_4
42 0 U VDDRFPA
41 0 U OSC_IN
40 0 U OSC_OUT
39 0 U VDDRF
38 0 U VDDHPA
37 0 U RF

*END*
*REMARK* SamacSys ECAD Model
20877156/2063538/2.50/49/2/Integrated Circuit
