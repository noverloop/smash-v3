*PADS-LIBRARY-PART-TYPES-V9*

ADF4351BCPZ QFN50P500X500X100-33N I ANA 8 1 0 0 0
TIMESTAMP 2026.05.19.18.24.42
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" ADF4351BCPZ
"Mouser Part Number" 584-ADF4351BCPZ
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/ADF4351BCPZ?qs=BpaRKvA4VqFCiUOrGPcIQw%3D%3D
"Arrow Part Number" ADF4351BCPZ
"Arrow Price/Stock" https://www.arrow.com/en/products/adf4351bcpz/analog-devices?utm_currency=USD&region=nac
"Description" Wideband Synthesizer with Integrated VCO
"Datasheet Link" http://componentsearchengine.com/Datasheets/3/ADF4351BCPZ.pdf
GATE 1 33 0
ADF4351BCPZ
1 0 U CLK
2 0 U DATA
3 0 U LE
4 0 U CE
5 0 U SW
6 0 U VP
7 0 U CPOUT
8 0 U CPGND
9 0 U AGND
10 0 U AVDD
11 0 U AGNDVCO_2
12 0 U RFOUTA+
13 0 U RFOUTA-
14 0 U RFOUTB+
15 0 U RFOUTB-
16 0 U VVCO_2
17 0 U VVCO
18 0 U AGNDVCO_3
19 0 U TEMP
20 0 U VTUNE
21 0 U AGNDVCO
22 0 U RSET
23 0 U VCOM
24 0 U VREF
25 0 U LD
26 0 U PDBRF
27 0 U DGND
28 0 U DVDD
29 0 U REFIN
30 0 U MUXOUT
31 0 U SDGND
32 0 U SDVDD
33 0 U EP

*END*
*REMARK* SamacSys ECAD Model
361375/2063538/2.50/33/0/Integrated Circuit
