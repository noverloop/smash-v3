*PADS-LIBRARY-PART-TYPES-V9*

LR2021IMLTRT QFN50P500X500X100-33N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.11.15.19.31.23
"Manufacturer_Name" SEMTECH
"Manufacturer_Part_Number" LR2021IMLTRT
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" RF Transceiver LoRa Plus Fourth-gen LoRa IP, Long Range, Low Power, Multi-band LoRa Transceiver
"Datasheet Link" https://static6.arrow.com/aropdfconversion/8c4c56f96ce73446dfb7d5351c178fb7af851e88/lr2021_datasheet_prelim0_1.pdf
"Geometry.Height" 1mm
GATE 1 33 0
LR2021IMLTRT
1 0 U VR_PA
2 0 U VPAX2
3 0 U NTC
4 0 U XTA
5 0 U XTB
6 0 U VTCXO/VNTC
7 0 U DIO11
8 0 U DIO10
9 0 U DIO9
10 0 U DIO8
11 0 U DIO7
12 0 U VDCC1
13 0 U VPAX1
14 0 U LXB
15 0 U GND_DCC
16 0 U LXA
24 0 U NSS
23 0 U SCK
22 0 U MOSI
21 0 U MISO
20 0 U NRESET
19 0 U DIO5
18 0 U DIO6
17 0 U VBAT
33 0 U EP
32 0 U RFO_HF
31 0 U RFI_HF
30 0 U GND
29 0 U RFI_LF
28 0 U RFO_LF1
27 0 U RFO_LF2
26 0 U VDCC2
25 0 U BUSY

*END*
*REMARK* SamacSys ECAD Model
20809842/2063538/2.50/33/3/Integrated Circuit
