*PADS-LIBRARY-PART-TYPES-V9*

RU1J002YNTCL SOTFL65P210X105-3N I TRX 9 1 0 0 0
TIMESTAMP 2026.11.21.22.35.47
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" RU1J002YNTCL
"Mouser Part Number" 755-RU1J002YNTCL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/RU1J002YNTCL?qs=npTsUczJOtM%2FefBcq0SyrQ%3D%3D
"Arrow Part Number" RU1J002YNTCL
"Arrow Price/Stock" https://www.arrow.com/en/products/ru1j002yntcl/rohm-semiconductor.html?utm_currency=USD&region=asia
"Description" 0.9V Drive Nch MOSFET
"Datasheet Link" https://fscdn.rohm.com/en/products/databook/datasheet/discrete/transistor/mosfet/ru1j002yn-e.pdf
"Geometry.Height" 1.05mm
GATE 1 3 0
RU1J002YNTCL
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
680056/2063473/2.50/3/2/MOSFET (N-Channel)
