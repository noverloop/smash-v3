*PADS-LIBRARY-PART-TYPES-V9*

BAT64-06-TP SOT95P237X125-3N I DIO 9 1 0 0 0
TIMESTAMP 2026.05.25.14.13.20
"Manufacturer_Name" MCC
"Manufacturer_Part_Number" BAT64-06-TP
"Mouser Part Number" 833-BAT64-06-TP
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Micro-Commercial-Components-MCC/BAT64-06-TP?qs=P1JMDcb91o7M%252BqFkYWXryg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Small Signal Schottky Diodes
"Datasheet Link" https://www.mccsemi.com/pdf/Products/BAT64-04~06(SOT-23).pdf
"Geometry.Height" 1.25mm
GATE 1 3 0
BAT64-06-TP
1 0 U K_1
2 0 U K_2
3 0 U COM_A

*END*
*REMARK* SamacSys ECAD Model
18012237/2063538/2.50/3/2/Schottky Diode
