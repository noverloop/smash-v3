*PADS-LIBRARY-PART-TYPES-V9*

STM32WBA55HGF6TR BGA41C35P13X7_298X276X50 I ANA 9 1 0 0 0
TIMESTAMP 2026.05.28.19.22.27
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STM32WBA55HGF6TR
"Mouser Part Number" 511-STM32WBA55HGF6TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STM32WBA55HGF6TR?qs=iLKYxzqNS75%2FahdwbfEDrA%3D%3D
"Arrow Part Number" STM32WBA55HGF6TR
"Arrow Price/Stock" https://www.arrow.com/en/products/stm32wba55hgf6tr/stmicroelectronics.html?utm_currency=USD&region=nac
"Description" Multiprotocol wireless 32-bit MCU Arm-based Cortex-M33 with TrustZone, FPU, Bluetooth LE and IEEE 802.15.4 radio solution
"Datasheet Link" https://www.st.com/resource/en/datasheet/stm32wba52ce.pdf
"Geometry.Height" 0.5mm
GATE 1 41 0
STM32WBA55HGF6TR
A6 0 U VDDRF
A8 0 U OSC_IN
A10 0 U VDD_1
A12 0 U VSS_SMPS
B5 0 U VDD_ANA
B7 0 U OSC__OUT
B9 0 U VSS_1
B11 0 U VDD11
B13 0 U VDD_SMPS
C2 0 U RF
C4 0 U VDD_HPA
C6 0 U VDDRF_PA
C8 0 U PH3-_BOOT0
C10 0 U PB12
C12 0 U VLX_SMPS
D1 0 U VSSRF_1
D3 0 U VSSRF_2
D5 0 U VSSRF_3
D7 0 U PA8
D9 0 U PA6
D11 0 U PA7
D13 0 U VSSA
E2 0 U NRST
E4 0 U PB15
E6 0 U PA12
E8 0 U PA13
E10 0 U PA1
E12 0 U VDDA
F1 0 U PA14
F3 0 U PA15
F5 0 U PB4
F7 0 U PC15-_OSC32__OUT
F9 0 U PB9
F11 0 U PA2
F13 0 U PA5
G2 0 U PB3
G4 0 U VDD_2
G6 0 U VSS_2
G8 0 U PC14-_OSC32__IN
G10 0 U PB8
G12 0 U PA0

*END*
*REMARK* SamacSys ECAD Model
20031905/2063538/2.50/41/2/Integrated Circuit
