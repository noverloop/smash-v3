*PADS-LIBRARY-PART-TYPES-V9*

6TPE470MI 10TCE330M I CAP 9 1 0 0 0
TIMESTAMP 2026.11.22.12.49.27
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" 6TPE470MI
"Mouser Part Number" 667-6TPE470MI
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/6TPE470MI?qs=OE1iw1LrrPEOBCILJlPBow%3D%3D
"Arrow Part Number" 6TPE470MI
"Arrow Price/Stock" https://www.arrow.com/en/products/6tpe470mi/panasonic?region=nac
"Description" Panasonic 470uF SMD Solid Polymer Tantalum Capacitor, 6.3 V +/-20%, POSCAP Series
"Datasheet Link" http://industrial.panasonic.com/cdbs/www-data/pdf/AAA8000/AAA8000C36.pdf
"Geometry.Height" 4mm
GATE 1 2 0
6TPE470MI
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
391959/2063303/2.50/2/2/Capacitor Polarised
