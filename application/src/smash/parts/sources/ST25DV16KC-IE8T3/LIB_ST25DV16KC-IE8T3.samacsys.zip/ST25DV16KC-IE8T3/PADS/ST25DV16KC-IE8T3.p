*PADS-LIBRARY-PART-TYPES-V9*

ST25DV16KC-IE8T3 SOP65P640X120-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.19.18.25.23
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" ST25DV16KC-IE8T3
"Mouser Part Number" 511-ST25DV16KC-IE8T3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/ST25DV16KC-IE8T3?qs=QNEnbhJQKvbdQyVZpeN4%252Bw%3D%3D
"Arrow Part Number" ST25DV16KC-IE8T3
"Arrow Price/Stock" https://www.arrow.com/en/products/st25dv16kc-ie8t3/stmicroelectronics?region=nac
"Description" Dynamic NFC/RFID tag IC with 4-, 16-, or 64-Kbit EEPROM, fast transfer mode capability, and optimized I2C
"Datasheet Link" https://www.st.com/resource/en/datasheet/st25dv04kc.pdf
"Geometry.Height" 1.2mm
GATE 1 8 0
ST25DV16KC-IE8T3
1 0 U V_EH
2 0 U AC0
3 0 U AC1
4 0 U VSS
8 0 U VCC
7 0 U GPO_(OPEN_DRAIN)
6 0 U SCL
5 0 U SDA

*END*
*REMARK* SamacSys ECAD Model
14991784/2063538/2.50/8/2/Integrated Circuit
