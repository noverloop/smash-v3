*PADS-LIBRARY-PART-TYPES-V9*

INA228AIDGSR SOP50P490X110-10N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.21.11.52.20
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" INA228AIDGSR
"Mouser Part Number" 595-INA228AIDGSR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/INA228AIDGSR?qs=pUKx8fyJudB2qGvt%252BmXPAg%3D%3D
"Arrow Part Number" INA228AIDGSR
"Arrow Price/Stock" https://www.arrow.com/en/products/ina228aidgsr/texas-instruments.html?utm_currency=USD&region=nac
"Description" Current & Power Monitors & Regulators 85-V, 20-bit, ultra-precise, I2C output current/voltage/power/energy/charge monitor with alert</p
"Datasheet Link" https://www.ti.com/general/docs/suppproductinfo.tsp?distId=10&gotoUrl=http%3A%2F%2Fwww.ti.com%2Flit%2Fgpn%2Fina228
"Geometry.Height" 1.1mm
GATE 1 10 0
INA228AIDGSR
1 0 U A1
2 0 U A0
3 0 U ALERT
4 0 U SDA
5 0 U SCL
10 0 U IN+
9 0 U IN-
8 0 U VBUS
7 0 U GND
6 0 U VS

*END*
*REMARK* SamacSys ECAD Model
13657917/2063303/2.50/10/3/Integrated Circuit
