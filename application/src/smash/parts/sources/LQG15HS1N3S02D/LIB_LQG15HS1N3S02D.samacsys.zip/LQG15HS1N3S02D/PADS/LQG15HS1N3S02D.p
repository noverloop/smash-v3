*PADS-LIBRARY-PART-TYPES-V9*

LQG15HS1N3S02D LQG15WH0N7B02D I IND 9 1 0 0 0
TIMESTAMP 2026.11.21.21.19.36
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" LQG15HS1N3S02D
"Mouser Part Number" 81-LQG15HS1N3S02D
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=81-LQG15HS1N3S02D
"Arrow Part Number" LQG15HS1N3S02D
"Arrow Price/Stock" https://www.arrow.com/en/products/lqg15hs1n3s02d/murata-manufacturing
"Description" Murata LQG15HS Series 0.0013 uH +/-0.3nH Multilayer SMD Inductor, 0402 Case, SRF: 6000MHz Q: 8 300mA dc 90m Rdc
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/P02/JELF243B-0010.pdf
"Geometry.Height" 0.6mm
GATE 1 2 0
LQG15HS1N3S02D
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
525641/2064551/2.50/2/2/Inductor
